/**
 * SCRIBE by AEPNKJ — After Effects ExtendScript Bridge
 * All host operations invoked from the panel via evalScript
 */

var SCRIBE = SCRIBE || {};

// ——— ES3 Polyfills for Modern JS Compatibility ———
if (!Array.prototype.indexOf) {
  Array.prototype.indexOf = function (searchElement, fromIndex) {
    var k;
    if (this == null) { throw new TypeError('"this" is null or not defined'); }
    var o = Object(this);
    var len = o.length >>> 0;
    if (len === 0) { return -1; }
    var n = fromIndex | 0;
    if (n >= len) { return -1; }
    k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
    while (k < len) {
      if (k in o && o[k] === searchElement) { return k; }
      k++;
    }
    return -1;
  };
}
if (!Array.prototype.forEach) {
  Array.prototype.forEach = function (callback, thisArg) {
    var T, k;
    if (this == null) { throw new TypeError('this is null or not defined'); }
    var O = Object(this);
    var len = O.length >>> 0;
    if (typeof callback !== 'function') { throw new TypeError(callback + ' is not a function'); }
    if (arguments.length > 1) { T = thisArg; }
    k = 0;
    while (k < len) {
      var kValue;
      if (k in O) {
        kValue = O[k];
        callback.call(T, kValue, k, O);
      }
      k++;
    }
  };
}
if (!Array.prototype.map) {
  Array.prototype.map = function (callback, thisArg) {
    var T, A, k;
    if (this == null) { throw new TypeError('this is null or not defined'); }
    var O = Object(this);
    var len = O.length >>> 0;
    if (typeof callback !== 'function') { throw new TypeError(callback + ' is not a function'); }
    if (arguments.length > 1) { T = thisArg; }
    A = new Array(len);
    k = 0;
    while (k < len) {
      var kValue, mappedValue;
      if (k in O) {
        kValue = O[k];
        mappedValue = callback.call(T, kValue, k, O);
        A[k] = mappedValue;
      }
      k++;
    }
    return A;
  };
}
if (!Array.prototype.filter) {
  Array.prototype.filter = function (func, thisArg) {
    if (this === void 0 || this === null) { throw new TypeError(); }
    var t = Object(this);
    var len = t.length >>> 0;
    if (typeof func !== 'function') { throw new TypeError(); }
    var res = [];
    var thisp = arguments[1];
    for (var i = 0; i < len; i++) {
      if (i in t) {
        var val = t[i];
        if (func.call(thisp, val, i, t)) { res.push(val); }
      }
    }
    return res;
  };
}
if (!Array.prototype.includes) {
  Array.prototype.includes = function (searchElement, fromIndex) {
    if (this == null) { throw new TypeError('"this" is null or not defined'); }
    var o = Object(this);
    var len = o.length >>> 0;
    if (len === 0) { return false; }
    var n = fromIndex | 0;
    var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
    while (k < len) {
      if (o[k] === searchElement) { return true; }
      k++;
    }
    return false;
  };
}
if (!String.prototype.trim) {
  String.prototype.trim = function () {
    return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  };
}
if (!String.prototype.includes) {
  String.prototype.includes = function (search, start) {
    if (typeof start !== 'number') { start = 0; }
    if (start + search.length > this.length) { return false; }
    else { return this.indexOf(search, start) !== -1; }
  };
}
if (!Object.keys) {
  Object.keys = (function () {
    var hasOwnProperty = Object.prototype.hasOwnProperty,
        hasDontEnumBug = !({ toString: null }).propertyIsEnumerable('toString'),
        dontEnums = [
          'toString',
          'toLocaleString',
          'valueOf',
          'hasOwnProperty',
          'isPrototypeOf',
          'propertyIsEnumerable',
          'constructor'
        ],
        dontEnumsLength = dontEnums.length;
    return function (obj) {
      if (typeof obj !== 'object' && (typeof obj !== 'function' || obj === null)) {
        throw new TypeError('Object.keys called on non-object');
      }
      var result = [], prop, i;
      for (prop in obj) {
        if (hasOwnProperty.call(obj, prop)) { result.push(prop); }
      }
      if (hasDontEnumBug) {
        for (i = 0; i < dontEnumsLength; i++) {
          if (hasOwnProperty.call(obj, dontEnums[i])) { result.push(dontEnums[i]); }
        }
      }
      return result;
    };
  }());
}
if (!Object.assign) {
  Object.assign = function (target) {
    if (target == null) { throw new TypeError('Cannot convert undefined or null to object'); }
    var to = Object(target);
    for (var index = 1; index < arguments.length; index++) {
      var nextSource = arguments[index];
      if (nextSource != null) {
        for (var nextKey in nextSource) {
          if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
            to[nextKey] = nextSource[nextKey];
          }
        }
      }
    }
    return to;
  };
}
if (!Array.prototype.find) {
  Array.prototype.find = function (predicate) {
    if (this == null) { throw new TypeError('"this" is null or not defined'); }
    var o = Object(this);
    var len = o.length >>> 0;
    if (typeof predicate !== 'function') { throw new TypeError('predicate must be a function'); }
    var thisArg = arguments[1];
    var k = 0;
    while (k < len) {
      var kValue = o[k];
      if (predicate.call(thisArg, kValue, k, o)) { return kValue; }
      k++;
    }
    return undefined;
  };
}
if (!Array.prototype.findIndex) {
  Array.prototype.findIndex = function (predicate) {
    if (this == null) { throw new TypeError('"this" is null or not defined'); }
    var o = Object(this);
    var len = o.length >>> 0;
    if (typeof predicate !== 'function') { throw new TypeError('predicate must be a function'); }
    var thisArg = arguments[1];
    var k = 0;
    while (k < len) {
      var kValue = o[k];
      if (predicate.call(thisArg, kValue, k, o)) { return k; }
      k++;
    }
    return -1;
  };
}
if (!Array.prototype.some) {
  Array.prototype.some = function (fun) {
    if (this == null) { throw new TypeError('Array.prototype.some called on null or undefined'); }
    if (typeof fun !== 'function') { throw new TypeError(); }
    var t = Object(this);
    var len = t.length >>> 0;
    var thisArg = arguments.length >= 2 ? arguments[1] : void 0;
    for (var i = 0; i < len; i++) {
      if (i in t && fun.call(thisArg, t[i], i, t)) { return true; }
    }
    return false;
  };
}
if (!Array.prototype.every) {
  Array.prototype.every = function (callbackfn, thisArg) {
    var T, k;
    if (this == null) { throw new TypeError('this is null or not defined'); }
    var O = Object(this);
    var len = O.length >>> 0;
    if (typeof callbackfn !== 'function') { throw new TypeError(); }
    if (arguments.length > 1) { T = thisArg; }
    k = 0;
    while (k < len) {
      var kValue;
      if (k in O) {
        kValue = O[k];
        var testResult = callbackfn.call(T, kValue, k, O);
        if (!testResult) { return false; }
      }
      k++;
    }
    return true;
  };
}
if (!Array.prototype.reduce) {
  Array.prototype.reduce = function (callback) {
    if (this === null || this === undefined) { throw new TypeError('Array.prototype.reduce called on null or undefined'); }
    if (typeof callback !== 'function') { throw new TypeError(callback + ' is not a function'); }
    var o = Object(this);
    var len = o.length >>> 0;
    var k = 0;
    var value;
    if (arguments.length >= 2) {
      value = arguments[1];
    } else {
      while (k < len && !(k in o)) { k++; }
      if (k >= len) { throw new TypeError('Reduce of empty array with no initial value'); }
      value = o[k++];
    }
    while (k < len) {
      if (k in o) { value = callback(value, o[k], k, o); }
      k++;
    }
    return value;
  };
}
if (!String.prototype.startsWith) {
  String.prototype.startsWith = function (search, pos) {
    pos = !pos || pos < 0 ? 0 : +pos;
    return this.substring(pos, pos + search.length) === search;
  };
}
if (!String.prototype.endsWith) {
  String.prototype.endsWith = function (search, this_len) {
    if (this_len === undefined || this_len > this.length) {
      this_len = this.length;
    }
    return this.substring(this_len - search.length, this_len) === search;
  };
}
if (!Object.values) {
  Object.values = function (obj) {
    if (obj == null) { throw new TypeError('Cannot convert undefined or null to object'); }
    var res = [];
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        res.push(obj[key]);
      }
    }
    return res;
  };
}
if (!Object.entries) {
  Object.entries = function (obj) {
    if (obj == null) { throw new TypeError('Cannot convert undefined or null to object'); }
    var res = [];
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        res.push([key, obj[key]]);
      }
    }
    return res;
  };
}

SCRIBE.version = "1.0.0";

// ——— Utilities ———

function scribeStringify(obj) {
  if (obj === undefined || obj === null) return "null";
  if (typeof obj === "string") return JSON.stringify(obj);
  if (typeof obj === "number" || typeof obj === "boolean") return String(obj);
  if (obj instanceof Array) {
    var items = [];
    for (var i = 0; i < obj.length; i++) {
      items.push(scribeStringify(obj[i]));
    }
    return "[" + items.join(",") + "]";
  }
  var pairs = [];
  for (var k in obj) {
    if (obj.hasOwnProperty(k)) {
      pairs.push(JSON.stringify(k) + ":" + scribeStringify(obj[k]));
    }
  }
  return "{" + pairs.join(",") + "}";
}

function scribeResult(ok, data, error) {
  return scribeStringify({
    ok: ok,
    data: data || null,
    error: error || null,
    timestamp: new Date().getTime(),
  });
}

function scribeParseJSON(str) {
  if (!str) return null;
  try {
    if (typeof JSON !== "undefined" && typeof JSON.parse === "function") {
      return JSON.parse(str);
    }
  } catch (e) {}
  try {
    return eval("(" + str + ")");
  } catch (e) {
    return null;
  }
}

function scribeActiveComp() {
  if (!app.project) return null;
  if (app.project.activeItem && app.project.activeItem instanceof CompItem) {
    return app.project.activeItem;
  }
  try {
    if (app.project.selection && app.project.selection.length) {
      for (var i = 0; i < app.project.selection.length; i++) {
        if (app.project.selection[i] instanceof CompItem) return app.project.selection[i];
      }
    }
  } catch (e) {}
  try {
    for (var j = 1; j <= app.project.numItems; j++) {
      if (app.project.item(j) instanceof CompItem) return app.project.item(j);
    }
  } catch (e2) {}
  return null;
}

function scribeSelectedLayers(comp) {
  var layers = [];
  if (!comp || !comp.selectedLayers) return layers;
  for (var i = 0; i < comp.selectedLayers.length; i++) {
    var L = comp.selectedLayers[i];
    layers.push({
      index: L.index,
      name: L.name,
      matchName: L.matchName,
      enabled: L.enabled,
      inPoint: L.inPoint,
      outPoint: L.outPoint,
      startTime: L.startTime,
    });
  }
  return layers;
}

function scribeLayerType(layer) {
  try {
    if (layer instanceof TextLayer) return "TextLayer";
    if (layer instanceof ShapeLayer) return "ShapeLayer";
    if (layer instanceof CameraLayer) return "CameraLayer";
    if (layer instanceof LightLayer) return "LightLayer";
    if (layer.nullLayer) return "NullLayer";
    if (layer.source instanceof CompItem) return "PreComp";
    if (layer.source instanceof FootageItem) {
      if (layer.source.mainSource instanceof SolidSource) return "SolidLayer";
      return "Footage";
    }
  } catch (e) {}
  return "AVLayer";
}

function scribeLayerScan(comp, limit) {
  var layers = [];
  if (!comp) return layers;
  var max = Math.min(comp.numLayers, limit || 50);
  for (var i = 1; i <= max; i++) {
    try {
      var L = comp.layer(i);
      layers.push({
        index: L.index,
        name: L.name,
        type: scribeLayerType(L),
        matchName: L.matchName,
        enabled: L.enabled,
        locked: L.locked,
        shy: L.shy,
        active: L.active,
        inPoint: L.inPoint,
        outPoint: L.outPoint,
      });
    } catch (e) {}
  }
  return layers;
}

function scribeSelectedLayerDetails(comp) {
  var selected = [];
  if (!comp || !comp.selectedLayers) return selected;
  for (var i = 0; i < comp.selectedLayers.length; i++) {
    try {
      var L = comp.selectedLayers[i];
      var props = {};
      try { props.position = L.transform.position.value; } catch (e1) {}
      try { props.scale = L.transform.scale.value; } catch (e2) {}
      try { props.opacity = L.transform.opacity.value; } catch (e3) {}
      try { props.rotation = L.transform.rotation.value; } catch (e4) {}
      selected.push({
        index: L.index,
        name: L.name,
        type: scribeLayerType(L),
        matchName: L.matchName,
        properties: props,
      });
    } catch (e) {}
  }
  return selected;
}

/** Use selected layer, else preferred index, else top layer */
function scribeResolveLayerIndex(comp, preferredIndex) {
  if (!comp || comp.numLayers < 1) return 0;
  if (comp.selectedLayers && comp.selectedLayers.length > 0) {
    return comp.selectedLayers[0].index;
  }
  var idx = preferredIndex || 1;
  if (idx >= 1 && idx <= comp.numLayers) return idx;
  return 1;
}

/** AE property access — supports Position/Scale and Transform.* aliases */
function scribeProp(layer, propertyPath) {
  var path = propertyPath;
  if (path === "Transform.Position") path = "Position";
  if (path === "Transform.Scale") path = "Scale";
  if (path === "Transform.Rotation") path = "Rotation";
  if (path === "Transform.Opacity") path = "Opacity";
  if (path === "Rotation") {
    try {
      return layer.property("Rotation");
    } catch (e1) {
      return layer.property("ADBE Rotate Z");
    }
  }
  var parts = path.split(".");
  var prop = layer;
  for (var i = 0; i < parts.length; i++) {
    prop = prop.property(parts[i]);
  }
  return prop;
}

function scribeSanitizeScript(script) {
  if (!script) return "";
  var s = String(script);
  s = s.replace(/\bconst\s+/g, "var ");
  s = s.replace(/\blet\s+/g, "var ");
  s = s.replace(/var\s+comp\s*=\s*app\.project\.activeItem\s*;/g, "var comp = scribeActiveComp();");
  return s;
}

// ——— Context ———

SCRIBE.ping = function () {
  return scribeResult(true, {
    version: SCRIBE.version,
    app: app.name,
    appVersion: app.version,
  });
};

SCRIBE.getContext = function () {
  try {
    var comp = scribeActiveComp();
    var ctx = {
      appName: app.name,
      appVersion: app.version,
      hasProject: !!app.project,
      comp: null,
      selectedLayers: [],
      layers: [],
      l0: null,
      l1: null,
      l2: null,
      time: null,
      frameRate: null,
    };
    if (comp) {
      ctx.comp = {
        name: comp.name,
        width: comp.width,
        height: comp.height,
        duration: comp.duration,
        frameRate: comp.frameRate,
        numLayers: comp.numLayers,
        workAreaStart: comp.workAreaStart,
        workAreaDuration: comp.workAreaDuration,
      };
      ctx.selectedLayers = scribeSelectedLayers(comp);
      ctx.layers = scribeLayerScan(comp, 50);
      ctx.time = comp.time;
      ctx.frameRate = comp.frameRate;
      ctx.l0 = {
        compId: comp.id,
        compName: comp.name,
        width: comp.width,
        height: comp.height,
        duration: comp.duration,
        frameRate: comp.frameRate,
        time: comp.time,
      };
      ctx.l1 = {
        layerCount: comp.numLayers,
        layers: ctx.layers,
      };
      ctx.l2 = {
        selectedCount: comp.selectedLayers ? comp.selectedLayers.length : 0,
        selectedLayers: scribeSelectedLayerDetails(comp),
      };
    }
    return scribeResult(true, ctx);
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Layer operations ———

SCRIBE.renameLayer = function (layerIndex, newName) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    layer.name = newName;
    return scribeResult(true, { name: layer.name });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.setLayerLabel = function (layerIndex, labelIndex) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    comp.layer(idx).label = labelIndex;
    return scribeResult(true, { label: labelIndex });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.addTextLayer = function (text, optionsJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var opts = optionsJson ? scribeParseJSON(optionsJson) : {};
    var layer = comp.layers.addText(text || "SCRIBE");
    var textProp = layer.property("Source Text");
    var doc = textProp.value;
    if (opts.fontSize) doc.fontSize = opts.fontSize;
    if (opts.fillColor) doc.fillColor = opts.fillColor;
    if (opts.font) doc.font = opts.font;
    textProp.setValue(doc);
    if (opts.position) layer.property("Position").setValue(opts.position);
    return scribeResult(true, { index: layer.index, name: layer.name });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Keyframes ———

SCRIBE.setKeyframe = function (layerIndex, propertyPath, time, valueJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    var parts = propertyPath.split(".");
    var prop = layer;
    for (var i = 0; i < parts.length; i++) {
      prop = prop.property(parts[i]);
    }
    var val = scribeParseJSON(valueJson);
    prop.setValueAtTime(time, val);
    return scribeResult(true, { property: propertyPath, time: time });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.applyEase = function (layerIndex, propertyPath, easeIn, easeOut) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    var parts = propertyPath.split(".");
    var prop = layer;
    for (var i = 0; i < parts.length; i++) {
      prop = prop.property(parts[i]);
    }
    var ei = easeIn ? [easeIn, easeIn] : [0.42, 0, 0.58, 1];
    var eo = easeOut ? [easeOut, easeOut] : [0.42, 0, 0.58, 1];
    for (var k = 1; k <= prop.numKeys; k++) {
      prop.setTemporalEaseAtKey(k, [ei, ei, ei], [eo, eo, eo]);
    }
    return scribeResult(true, { keys: prop.numKeys });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Expressions ———

SCRIBE.setExpression = function (layerIndex, propertyPath, expression) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    var parts = propertyPath.split(".");
    var prop = layer;
    for (var i = 0; i < parts.length; i++) {
      prop = prop.property(parts[i]);
    }
    prop.expression = expression;
    return scribeResult(true, { expression: expression });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.clearExpression = function (layerIndex, propertyPath) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    var parts = propertyPath.split(".");
    var prop = layer;
    for (var i = 0; i < parts.length; i++) {
      prop = prop.property(parts[i]);
    }
    prop.expression = "";
    return scribeResult(true, null);
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.inspectExpression = function (layerIndex, propertyPath) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    var parts = propertyPath.split(".");
    var prop = layer;
    for (var i = 0; i < parts.length; i++) {
      prop = prop.property(parts[i]);
    }
    var errorMsg = null;
    try {
      if (prop.expressionError && prop.expressionError !== "") {
        errorMsg = prop.expressionError;
      }
    } catch (ignore) {}
    return scribeResult(true, {
      expression: prop.expression || "",
      expressionEnabled: prop.expressionEnabled || false,
      error: errorMsg,
      property: prop.name || propertyPath,
      layer: layer.name,
    });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Effects (color grading) ———

SCRIBE.addEffect = function (layerIndex, matchName) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    var fx = layer.Effects.addProperty(matchName);
    return scribeResult(true, { name: fx.name, matchName: matchName });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.getInstalledEffects = function () {
  try {
    if (!app.effects) return scribeResult(false, null, "app.effects not supported");
    var all = app.effects;
    var list = [];
    for (var i = 0; i < all.length; i++) {
      var fx = all[i];
      list.push({ displayName: fx.displayName, matchName: fx.matchName, category: fx.category });
    }
    return scribeResult(true, list);
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};


SCRIBE.setEffectParam = function (layerIndex, effectIndex, paramIndex, valueJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layer selected");
    var layer = comp.layer(idx);
    var fx = layer.effect(effectIndex);
    var val = scribeParseJSON(valueJson);
    fx.property(paramIndex).setValue(val);
    return scribeResult(true, null);
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Adjustment layer + Lumetri-style stack ———

SCRIBE.addAdjustmentGrade = function (presetJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var preset = scribeParseJSON(presetJson) || {};
    var adj = comp.layers.addSolid([1, 1, 1], "SCRIBE Grade", comp.width, comp.height, 1);
    adj.adjustmentLayer = true;
    adj.moveToBeginning();
    var curves = adj.Effects.addProperty("ADBE CurvesCustom");
    if (preset.contrast !== undefined) {
      try {
        curves.property("ADBE CurvesCustomIntensity").setValue(preset.contrast);
      } catch (ignore) {}
    }
    if (preset.tint) {
      var tint = adj.Effects.addProperty("ADBE Tint");
      tint.property("ADBE Tint-Color").setValue(preset.tint);
      tint.property("ADBE Tint-Amount").setValue(preset.tintAmount || 25);
    }
    return scribeResult(true, { index: adj.index, name: adj.name });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Captions: word-by-word text layers ———

SCRIBE.createCaptionLayers = function (wordsJson, styleJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var words = scribeParseJSON(wordsJson) || [];
    var style = styleJson ? scribeParseJSON(styleJson) : {};
    var created = [];
    var parentNull = comp.layers.addNull();
    parentNull.name = "SCRIBE Captions";
    for (var w = 0; w < words.length; w++) {
      var word = words[w];
      var layer = comp.layers.addText(word.text);
      layer.name = "Caption: " + word.text;
      layer.parent = parentNull;
      layer.inPoint = word.start;
      layer.outPoint = word.end;
      var doc = layer.property("Source Text").value;
      doc.fontSize = style.fontSize || 72;
      doc.fillColor = style.fillColor || [1, 1, 1];
      doc.justification = ParagraphJustification.CENTER_JUSTIFY;
      layer.property("Source Text").setValue(doc);
      layer.property("Position").setValue([
        comp.width / 2,
        style.y || comp.height * 0.85,
      ]);
      layer.property("Scale").setValueAtTime(word.start, [0, 0]);
      layer.property("Scale").setValueAtTime(word.start + 0.08, [100, 100]);
      created.push({ index: layer.index, text: word.text });
    }
    return scribeResult(true, { parentIndex: parentNull.index, layers: created });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Timeline intelligence ———

SCRIBE.analyzeComposition = function () {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var unused = [];
    var heavy = [];
    var brokenExprs = [];
    for (var i = 1; i <= comp.numLayers; i++) {
      var L = comp.layer(i);
      if (L.enabled === false && L.inPoint >= comp.duration) {
        unused.push({ index: i, name: L.name });
      }
      if (L.Effects && L.Effects.numProperties > 5) {
        heavy.push({ index: i, name: L.name, effects: L.Effects.numProperties });
      }
    }
    return scribeResult(true, {
      layerCount: comp.numLayers,
      unused: unused,
      heavy: heavy,
      brokenExprs: brokenExprs,
      duration: comp.duration,
      frameRate: comp.frameRate,
    });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.organizeLayers = function () {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var folders = {};
    for (var i = 1; i <= comp.numLayers; i++) {
      var L = comp.layer(i);
      var prefix = L.name.split("_")[0] || "Misc";
      if (!folders[prefix]) folders[prefix] = [];
      folders[prefix].push(L);
    }
    var renamed = 0;
    for (var key in folders) {
      if (folders.hasOwnProperty(key)) {
        var group = folders[key];
        for (var g = 0; g < group.length; g++) {
          if (group[g].name.indexOf("SCRIBE|") !== 0) {
            group[g].name = "SCRIBE|" + key + "|" + group[g].name;
            renamed++;
          }
        }
      }
    }
    return scribeResult(true, { renamed: renamed });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Render queue ———

SCRIBE.addToRenderQueue = function (presetJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var preset = presetJson ? scribeParseJSON(presetJson) : {};
    var rq = app.project.renderQueue.items.add(comp);
    if (preset.outputModule) {
      rq.outputModule(1).applyTemplate(preset.outputModule);
    }
    if (preset.settingsTemplate) {
      rq.applyTemplate(preset.settingsTemplate);
    }
    return scribeResult(true, { queueIndex: rq.index });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

// ——— Tier 3: AI-generated ExtendScript (sandboxed) ———

function scribeValidateAiScript(script) {
  if (!script || typeof script !== "string") return "Script is empty";
  if (script.length > 50000) return "Script too long";
  var blocked = [
    "app.quit",
    "app.project.close",
    "app.project.remove",
    "app.project.save",
    "system.callSystem",
    "system.exec",
    "executeCommand",
    "BridgeTalk",
    "$.evalFile",
    "$.write",
    "#include",
    "import ",
    "require(",
    "new File(",
    "new Socket",
    "NetworkAccess",
    "app.doScript",
    "app.executeCommand",
  ];
  var lower = script.toLowerCase();
  for (var b = 0; b < blocked.length; b++) {
    if (lower.indexOf(blocked[b].toLowerCase()) !== -1) {
      return "Blocked: " + blocked[b];
    }
  }
  return null;
}

// ——— Sandbox Studio (Canvas ↔ AE) ———

SCRIBE.getLayerTransformAtTime = function (layerIndex, timeSec) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layers in composition");
    var layer = comp.layer(idx);
    var t = timeSec !== undefined && timeSec !== null ? timeSec : comp.time;
    var pos = layer.property("Position").valueAtTime(t, false);
    var scale = layer.property("Scale").valueAtTime(t, false);
    var rot = 0;
    try {
      rot = layer.property("Rotation").valueAtTime(t, false);
    } catch (rIgnore) {
      try {
        rot = layer.property("ADBE Rotate Z").valueAtTime(t, false);
      } catch (r2) {}
    }
    return scribeResult(true, {
      layerIndex: idx,
      layerName: layer.name,
      time: t,
      position: [pos[0], pos[1]],
      scale: [scale[0], scale[1]],
      rotation: rot,
    });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.sampleLayerPath = function (layerIndex, optionsJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var idx = scribeResolveLayerIndex(comp, layerIndex);
    if (!idx) return scribeResult(false, null, "No layers in composition");
    var layer = comp.layer(idx);
    var opts = optionsJson ? scribeParseJSON(optionsJson) : {};
    var samples = opts.samples || 40;
    if (samples < 2) samples = 2;
    if (samples > 200) samples = 200;
    var start = opts.startTime !== undefined ? opts.startTime : comp.workAreaStart;
    var end =
      opts.endTime !== undefined ? opts.endTime : start + comp.workAreaDuration;
    if (end <= start) end = start + comp.duration;
    var points = [];
    var i;
    for (i = 0; i < samples; i++) {
      var t = start + ((end - start) * i) / (samples - 1);
      var pos = layer.property("Position").valueAtTime(t, false);
      points.push({ x: pos[0], y: pos[1], t: t - start });
    }
    return scribeResult(true, {
      points: points,
      layerIndex: idx,
      layerName: layer.name,
      startTime: start,
      duration: end - start,
      compWidth: comp.width,
      compHeight: comp.height,
    });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.exportPathToNull = function (specJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var spec = specJson ? scribeParseJSON(specJson) : {};
    var points = spec.points || [];
    if (!points.length) return scribeResult(false, null, "No path points");

    app.beginUndoGroup("SCRIBE Canvas Path");
    var nullLayer = comp.layers.addNull();
    nullLayer.name = spec.name || "SCRIBE Path";
    var startTime = spec.startTime !== undefined ? spec.startTime : comp.time;
    var duration = spec.duration;
    if (!duration && points.length > 1) {
      duration = points[points.length - 1].t || 5;
    }
    if (!duration) duration = 5;

    nullLayer.inPoint = startTime;
    nullLayer.outPoint = startTime + duration;

    var posProp = nullLayer.property("Position");
    var p;
    for (p = 0; p < points.length; p++) {
      var pt = points[p];
      var keyTime = startTime + (pt.t !== undefined ? pt.t : 0);
      posProp.setValueAtTime(keyTime, [pt.x, pt.y]);
    }

    if (spec.parentToLayerIndex) {
      var parentIdx = spec.parentToLayerIndex;
      if (parentIdx >= 1 && parentIdx <= comp.numLayers) {
        nullLayer.parent = comp.layer(parentIdx);
      }
    }

    app.endUndoGroup();
    return scribeResult(true, {
      index: nullLayer.index,
      name: nullLayer.name,
      keys: posProp.numKeys,
      inPoint: nullLayer.inPoint,
      outPoint: nullLayer.outPoint,
    });
  } catch (e) {
    try {
      app.endUndoGroup();
    } catch (ignore) {}
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.createBarChart = function (dataJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var spec = dataJson ? scribeParseJSON(dataJson) : {};
    var rows = spec.data || spec.rows || [];
    if (!rows.length) return scribeResult(false, null, "No chart data");

    app.beginUndoGroup("SCRIBE Data Chart");
    var maxVal = 0;
    var r;
    for (r = 0; r < rows.length; r++) {
      var v = rows[r].value !== undefined ? rows[r].value : rows[r].v;
      if (v > maxVal) maxVal = v;
    }
    if (maxVal <= 0) maxVal = 1;

    var margin = spec.margin || 80;
    var chartW = comp.width - margin * 2;
    var chartH = comp.height - margin * 2;
    var barW = chartW / rows.length * 0.65;
    var gap = chartW / rows.length * 0.35;
    var baseY = comp.height - margin;
    var created = [];
    var startTime = spec.startTime !== undefined ? spec.startTime : 0;
    var duration = spec.duration !== undefined ? spec.duration : comp.duration;

    for (r = 0; r < rows.length; r++) {
      var val = rows[r].value !== undefined ? rows[r].value : rows[r].v;
      var label = rows[r].label || rows[r].l || "Bar " + (r + 1);
      var barH = (val / maxVal) * chartH;
      var cx = margin + r * (barW + gap) + barW / 2;
      var cy = baseY - barH / 2;

      var shape = comp.layers.addShape();
      shape.name = "Chart: " + label;
      shape.inPoint = startTime;
      shape.outPoint = startTime + duration;
      shape.property("Position").setValue([cx, cy]);
      var contents = shape.property("Contents");
      var rect = contents.addProperty("ADBE Vector Shape - Rect");
      rect.property("Size").setValue([barW, barH]);
      var fill = contents.addProperty("ADBE Vector Graphic - Fill");
      var hue = (r / rows.length) * 0.55 + 0.35;
      fill.property("Color").setValue([0.2 + hue * 0.5, 0.4, 0.9 - hue * 0.3]);
      created.push({ index: shape.index, name: shape.name, value: val });
    }

    app.endUndoGroup();
    return scribeResult(true, { count: created.length, bars: created });
  } catch (e) {
    try {
      app.endUndoGroup();
    } catch (ignore) {}
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.importPngSequence = function (folderPath, optionsJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var folder = new Folder(folderPath);
    if (!folder.exists) return scribeResult(false, null, "Folder not found");
    var files = folder.getFiles("*.png");
    if (!files || files.length < 1) return scribeResult(false, null, "No PNG files in folder");

    var fileList = [];
    var fi;
    for (fi = 0; fi < files.length; fi++) {
      fileList.push(files[fi]);
    }
    fileList.sort(function (a, b) {
      var numA = parseInt(a.name.replace(/[^0-9]/g, ""), 10) || 0;
      var numB = parseInt(b.name.replace(/[^0-9]/g, ""), 10) || 0;
      return numA - numB;
    });

    app.beginUndoGroup("SCRIBE PNG Sequence");
    var opts = optionsJson ? scribeParseJSON(optionsJson) : {};
    var footage;
    var layer;
    try {
      var importOpts = new ImportOptions(fileList[0]);
      importOpts.sequence = true;
      importOpts.forceAlphabetical = true;
      footage = app.project.importFile(importOpts);
    } catch (seqErr) {
      var singleOpts = new ImportOptions(fileList[0]);
      footage = app.project.importFile(singleOpts);
    }
    layer = comp.layers.add(footage);
    var startTime = opts.startTime !== undefined ? opts.startTime : comp.time;
    layer.startTime = startTime;
    if (opts.inPoint !== undefined) layer.inPoint = opts.inPoint;
    if (opts.outPoint !== undefined) layer.outPoint = opts.outPoint;
    layer.name = opts.name || "SCRIBE Capture";
    app.endUndoGroup();
    return scribeResult(true, {
      layerIndex: layer.index,
      name: layer.name,
      frameCount: fileList.length,
      folder: folderPath,
    });
  } catch (e) {
    try {
      app.endUndoGroup();
    } catch (ignore) {}
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.exportCompPreview = function (optionsJson) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var opts = optionsJson ? scribeParseJSON(optionsJson) : {};
    var fps = opts.fps || 2;
    var maxFrames = opts.maxFrames || 90;
    
    var tempDirName = "scribe_preview_" + new Date().getTime();
    var tempFolder = new Folder(Folder.temp.fsName + "/" + tempDirName);
    if (!tempFolder.exists) tempFolder.create();
    
    var duration = comp.duration;
    var width = comp.width;
    var height = comp.height;
    
    var step = 1 / fps;
    var frameCount = 0;
    var frames = [];
    var originalTime = comp.time;
    
    for (var t = 0; t < duration; t += step) {
      if (frameCount >= maxFrames) break;
      comp.time = t;
      var padCount = ("0000" + frameCount).slice(-4);
      var frameFile = new File(tempFolder.fsName + "/frame_" + padCount + ".png");
      comp.saveFrameToPng(t, frameFile);
      frames.push(frameFile.fsName);
      frameCount++;
    }
    
    comp.time = originalTime;
    
    return scribeResult(true, {
      folder: tempFolder.fsName,
      frames: frames,
      frameCount: frameCount,
      fps: fps,
      duration: duration,
      width: width,
      height: height
    });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.getSelectedLayerVideoPath = function () {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    if (!comp.selectedLayers || comp.selectedLayers.length === 0) {
      return scribeResult(false, null, "Please select a video layer in the active composition");
    }
    var layer = comp.selectedLayers[0];
    if (!layer.source || !layer.source.file) {
      return scribeResult(false, null, "Selected layer has no source video file. Please select a footage layer.");
    }
    return scribeResult(true, {
      path: layer.source.file.fsName,
      name: layer.source.name,
      duration: layer.source.duration
    });
  } catch (e) {
    return scribeResult(false, null, String(e));
  }
};

SCRIBE.importVideoFile = function (filePath, name) {
  try {
    var comp = scribeActiveComp();
    if (!comp) return scribeResult(false, null, "No active composition");
    var file = new File(filePath);
    if (!file.exists) return scribeResult(false, null, "File not found: " + filePath);
    
    app.beginUndoGroup("Import SCRIBE Edited Video");
    var footage = app.project.importFile(new ImportOptions(file));
    var layer = comp.layers.add(footage);
    if (name) layer.name = name;
    layer.startTime = comp.time;
    app.endUndoGroup();
    return scribeResult(true, { index: layer.index, name: layer.name });
  } catch (e) {
    try { app.endUndoGroup(); } catch (ignore) {}
    return scribeResult(false, null, String(e));
  }
};


SCRIBE.runAiScript = function (script) {
  script = scribeSanitizeScript(script);
  var blockReason = scribeValidateAiScript(script);
  if (blockReason) return scribeResult(false, null, blockReason);

  var comp = scribeActiveComp();
  var isWindowScript = script.indexOf("new Window") !== -1;
  if (!comp && !isWindowScript) {
    return scribeResult(false, null, "No active composition — open a comp in the timeline");
  }

  if (isWindowScript) {
    if ($.global.scribeActiveWindow && $.global.scribeActiveWindow instanceof Window) {
      try {
        $.global.scribeActiveWindow.close();
      } catch (ignore) {}
    }
    $.global.scribeActiveWindow = null;
    script = script.replace(/\bnew\s+Window\b/g, "$.global.scribeActiveWindow = new Window");
  }

  app.beginUndoGroup("SCRIBE AI Script");
  try {
    eval(script);
    
    if (isWindowScript && $.global.scribeActiveWindow && $.global.scribeActiveWindow instanceof Window) {
      if (!$.global.scribeActiveWindow.visible) {
        $.global.scribeActiveWindow.center();
        $.global.scribeActiveWindow.show();
      }
    }

    app.endUndoGroup();
    return scribeResult(true, {
      comp: comp ? comp.name : null,
      layers: comp ? comp.numLayers : 0,
    });
  } catch (e) {
    try {
      app.endUndoGroup();
    } catch (ignore) {}
    return scribeResult(false, null, String(e) + (e.line ? " on line " + e.line : ""));
  }
};

// ——— Undo group wrapper for batched AI actions ———

SCRIBE.executeBatch = function (commandsJson) {
  try {
    var commands = scribeParseJSON(commandsJson) || [];
    app.beginUndoGroup("SCRIBE AI Action");
    var results = [];
    for (var c = 0; c < commands.length; c++) {
      var cmd = commands[c];
      var fn = SCRIBE[cmd.method];
      if (typeof fn === "function") {
        results.push(fn.apply(SCRIBE, cmd.args));
      }
    }
    app.endUndoGroup();
    return scribeResult(true, { results: results });
  } catch (e) {
    try { app.endUndoGroup(); } catch (ignore) {}
    return scribeResult(false, null, String(e) + (e.line ? " on line " + e.line : ""));
  }
};

// ——— Dispatcher (called from panel) ———

function scribeDispatch(payloadJson) {
  try {
    var payload = scribeParseJSON(payloadJson) || {};
    var method = payload.method;
    var args = payload.args || [];
    if (!SCRIBE[method] || typeof SCRIBE[method] !== "function") {
      return scribeResult(false, null, "Unknown method: " + method);
    }
    return SCRIBE[method].apply(SCRIBE, args);
  } catch (e) {
    return scribeResult(false, null, String(e) + (e.line ? " on line " + e.line : ""));
  }
}

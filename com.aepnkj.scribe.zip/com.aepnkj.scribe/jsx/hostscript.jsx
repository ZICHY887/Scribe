/**
 * SCRIBE by AEPNKJ — ExtendScript host entry
 * Loaded by CEP manifest ScriptPath
 */
#include "ae-bridge.jsx"

// Fallback if #include fails (common on some AE / CEP setups)
try {
  if (typeof scribeDispatch !== "function") {
    var __scribeDir = new File($.fileName).parent;
    $.evalFile(new File(__scribeDir.fsName + "/ae-bridge.jsx"));
  }
} catch (__scribeErr) {
  $.writeln("[SCRIBE] Could not load ae-bridge.jsx: " + __scribeErr);
}

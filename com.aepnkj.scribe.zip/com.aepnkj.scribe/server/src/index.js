/**
 * SCRIBE by AEPNKJ — AI Backend Server
 * Express + WebSocket + serves panel UI at /
 */

import "dotenv/config";
import dns from "dns";
dns.setDefaultResultOrder("ipv4first");
import express from "express";
import cors from "cors";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import path from "path";
import { fileURLToPath } from "url";
import { existsSync } from "fs";
import { aiRouter } from "./routes/ai.js";
import { authRouter } from "./routes/auth.js";
import { settingsRouter } from "./routes/settings.js";
import { sandboxRouter } from "./routes/sandbox.js";
import { autoEditRouter } from "./routes/auto-edit.js";
import { voiceRouter } from "./routes/voice.js";
import { getAIStatus } from "./lib/settings-store.js";


const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3742;
const CLIENT_DIR = path.resolve(__dirname, "../../cep/client");
const HAS_UI = existsSync(path.join(CLIENT_DIR, "index.html"));

const app = express();
const server = createServer(app);

app.use(cors());
app.use(express.json({ limit: "200mb" }));

app.get("/health", (_req, res) => {
  const ai = getAIStatus();
  res.json({
    ok: true,
    service: "scribe-by-aepnkj",
    version: "1.0.0",
    ai: ai.openai || ai.gemini || ai.ollama,
    openai: ai.openai,
    gemini: ai.gemini,
    ollama: ai.ollama,
    ollamaModel: ai.ollamaModel,
    ui: HAS_UI,
  });
});

app.use("/api/auth", authRouter);
app.use("/api/settings", settingsRouter);
app.use("/api/sandbox", sandboxRouter);
app.use("/api/ai", aiRouter);
app.use("/api/auto-edit", autoEditRouter);
app.use("/api/voice", voiceRouter);

if (HAS_UI) {
  app.use(express.static(CLIENT_DIR));
  app.get("/", (_req, res) => {
    res.sendFile(path.join(CLIENT_DIR, "index.html"));
  });
} else {
  app.get("/", (_req, res) => {
    res.type("html").send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>SCRIBE by AEPNKJ</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: system-ui, sans-serif;
      background: #050508;
      color: #e5e5e5;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }
    .card {
      max-width: 520px;
      background: #12121c;
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 16px;
      padding: 2rem;
    }
    h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
    h1 span { color: #818cf8; }
    p { color: rgba(255,255,255,0.55); line-height: 1.6; margin: 1rem 0; font-size: 0.95rem; }
    .ok { color: #34d399; font-weight: 600; }
    code {
      background: rgba(255,255,255,0.06);
      padding: 0.15rem 0.4rem;
      border-radius: 4px;
      font-size: 0.85rem;
    }
    ol { margin: 1rem 0 0 1.25rem; color: rgba(255,255,255,0.7); }
    li { margin: 0.5rem 0; }
  </style>
</head>
<body>
  <div class="card">
    <h1><span>SCRIBE</span> AI Server</h1>
    <p class="ok">✓ Server is running on port ${PORT}</p>
    <p>The panel UI is not built yet. Build it once, then refresh this page:</p>
    <ol>
      <li>Open Command Prompt in the project folder</li>
      <li>Run <code>npm.cmd run build</code></li>
      <li>Restart <code>start-server.bat</code></li>
    </ol>
    <p style="margin-top:1.5rem">Or use SCRIBE inside After Effects:<br>
    <strong>Window → Extensions → SCRIBE by AEPNKJ</strong></p>
    <p style="margin-top:1rem;font-size:0.85rem">API: <a href="/health" style="color:#818cf8">/health</a></p>
  </div>
</body>
</html>`);
  });
}

const wss = new WebSocketServer({ server, path: "/ws" });

const liveClients = new Set();

wss.on("connection", (ws) => {
  liveClients.add(ws);
  ws.send(JSON.stringify({ type: "connected", message: "SCRIBE live bridge ready" }));

  ws.on("close", () => liveClients.delete(ws));

  ws.on("message", (raw) => {
    try {
      const msg = JSON.parse(String(raw));
      if (msg.type === "ping") {
        ws.send(JSON.stringify({ type: "pong", t: Date.now() }));
        return;
      }
      if (msg.type === "execute-script" && msg.script) {
        const packet = JSON.stringify({ type: "execute-script", script: msg.script });
        for (const client of liveClients) {
          if (client !== ws && client.readyState === 1) client.send(packet);
        }
        return;
      }
      // execute-command removed for security (RCE prevention)
      if (msg.type === "ae-context" && msg.payload) {
        const packet = JSON.stringify({ type: "ae-context", payload: msg.payload, t: Date.now() });
        for (const client of liveClients) {
          if (client !== ws && client.readyState === 1) client.send(packet);
        }
        return;
      }
      if (msg.type === "broadcast" && msg.payload) {
        const packet = JSON.stringify({ type: msg.channel || "event", payload: msg.payload });
        for (const client of liveClients) {
          if (client.readyState === 1) client.send(packet);
        }
      }
    } catch {
      ws.send(JSON.stringify({ type: "error", message: "Invalid message" }));
    }
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`SCRIBE server listening on http://127.0.0.1:${PORT}`);
  if (HAS_UI) {
    console.log(`SCRIBE panel UI → http://127.0.0.1:${PORT}/`);
  } else {
    console.log(`UI not built — run "npm.cmd run build" from project root, then restart.`);
  }
  console.log(`Health check → http://127.0.0.1:${PORT}/health`);
});

---
name: ae-scripting-master
description: Expert in After Effects scripting following Adobe's official ExtendScript guidelines and best practices
---

# After Effects Scripting Expert - Complete Guide

## Table of Contents
1. [Core Rules & Standards](#core-rules--standards)
2. [Quick Start Examples](#quick-start-examples)
3. [Basic Patterns](#basic-patterns)
4. [Intermediate Techniques](#intermediate-techniques)
5. [Advanced Operations](#advanced-operations)
6. [Common Pitfalls & Gotchas](#common-pitfalls--gotchas)
7. [Real-World Examples](#real-world-examples)
8. [Reference Tables](#reference-tables)
9. [Further Resources](#further-resources)

---

## Core Rules & Standards

### Essential Rules
- **Always use ExtendScript syntax (ES3)** - No modern JavaScript features
- **Follow Adobe's official scripting guidelines**
- **Include error handling with try-catch blocks**
- **Test for app.project existence before operations**
- **Use descriptive variable names in English**
- **Always wrap code in IIFE** (Immediately Invoked Function Expression)
- **Use app.beginUndoGroup() and app.endUndoGroup()**
- **Validate all inputs before processing**
- **Provide clear, actionable error messages**
- **Comment complex operations thoroughly**

### Reference Documents
When generating scripts, consult these Adobe official docs:
- after-effects-scripting-guide.pdf
- extendscript-toolkit-guide.pdf
- Check `/mnt/skills/user/ae-scripting-master/` for documentation

### Code Structure Pattern
Always follow this pattern:
1. Check if After Effects is running
2. Validate project exists
3. Create undo group
4. Execute operations
5. Handle errors gracefully
6. Close undo group in finally block

---

## Quick Start Examples

### Hello World Script
```javascript
(function() {
    alert("Hello from After Effects!");
})();
```

### Create Composition and Add Text
```javascript
(function() {
    if (!(app instanceof Application) || !app.project) {
        alert("Please open After Effects with a project");
        return;
    }
    
    app.beginUndoGroup("Quick Text Comp");
    
    try {
        // Create composition
        var comp = app.project.items.addComp("Text Comp", 1920, 1080, 1.0, 10, 30);
        
        // Add text layer
        var textLayer = comp.layers.addText("Hello After Effects!");
        var textProp = textLayer.property("ADBE Text Properties").property("ADBE Text Document");
        var textDoc = textProp.value;
        textDoc.fontSize = 100;
        textDoc.fillColor = [1, 1, 1];
        textDoc.justification = ParagraphJustification.CENTER_JUSTIFY;
        textProp.setValue(textDoc);
        
        // Center text
        var pos = textLayer.property("ADBE Transform Group").property("ADBE Position");
        pos.setValue([comp.width/2, comp.height/2]);
        
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
})();
```

### Batch Apply Effect to Selected Layers
```javascript
(function() {
    app.beginUndoGroup("Batch Apply Blur");
    
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            alert("Please select a composition");
            return;
        }
        
        var layers = comp.selectedLayers;
        if (layers.length === 0) {
            alert("Please select at least one layer");
            return;
        }
        
        for (var i = 0; i < layers.length; i++) {
            var blur = layers[i].property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
            blur.property("ADBE Gaussian Blur 2-0001").setValue(20);
        }
        
        alert("Applied Gaussian Blur to " + layers.length + " layer(s)");
        
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
})();
```

---

## Basic Patterns

### Basic Script Template
```javascript
(function() {
    // Check if After Effects is available
    if (!(app instanceof Application)) {
        alert("This script requires After Effects");
        return;
    }
    
    app.beginUndoGroup("Script Name");
    
    try {
        // Check if project exists
        if (!app.project) {
            alert("Please open a project first");
            return;
        }
        
        // Your code here
        
    } catch (e) {
        alert("Error: " + e.toString() + "\nLine: " + e.line);
    } finally {
        app.endUndoGroup();
    }
})();
```

### Creating Compositions
```javascript
// Create a new composition
var comp = app.project.items.addComp(
    "My Comp",      // name
    1920,           // width
    1080,           // height
    1.0,            // pixel aspect ratio
    30,             // duration in seconds
    30              // frame rate
);

// Access active composition
var activeComp = app.project.activeItem;
if (activeComp && activeComp instanceof CompItem) {
    // Work with active comp
}

// Duplicate composition
var duplicateComp = activeComp.duplicate();
```

### Working with Layers
```javascript
// Add a solid layer
var solidLayer = comp.layers.addSolid(
    [1, 0, 0],      // color (RGB 0-1)
    "Red Solid",    // name
    1920,           // width
    1080,           // height
    1.0             // pixel aspect ratio
);

// Add a text layer
var textLayer = comp.layers.addText("Hello World");
var textProp = textLayer.property("ADBE Text Properties").property("ADBE Text Document");
var textDocument = textProp.value;
textDocument.fontSize = 72;
textDocument.fillColor = [1, 1, 1];
textProp.setValue(textDocument);

// Add a shape layer
var shapeLayer = comp.layers.addShape();
shapeLayer.name = "My Shape";

// Add a null object
var nullLayer = comp.layers.addNull();
nullLayer.name = "Control Null";

// Duplicate layer
var duplicatedLayer = layer.duplicate();

// Parent a layer
childLayer.parent = parentLayer;

// Lock/unlock layer
layer.locked = true;
layer.locked = false;

// Solo layer
layer.solo = true;

// Shy layer
layer.shy = true;
comp.hideShyLayers = true;
```

### Importing Files
```javascript
// Import file
var file = new File("/path/to/file.mov");
if (file.exists) {
    var importOptions = new ImportOptions(file);
    var footage = app.project.importFile(importOptions);
    
    // Add to composition
    var layer = comp.layers.add(footage);
}

// Import file as composition (for image sequences or layered files)
var importOptions = new ImportOptions(file);
importOptions.importAs = ImportAsType.COMP;
var importedComp = app.project.importFile(importOptions);

// Import sequence
var importOptions = new ImportOptions(file);
importOptions.sequence = true;
var sequence = app.project.importFile(importOptions);

// Import multiple files
var files = File.openDialog("Select files to import", "", true);
if (files) {
    for (var i = 0; i < files.length; i++) {
        var importOptions = new ImportOptions(files[i]);
        app.project.importFile(importOptions);
    }
}
```

### Working with Properties
```javascript
// Get property by name
var positionProp = layer.property("Transform").property("Position");

// Using matchName (more reliable and language-independent)
var positionProp = layer.property("ADBE Transform Group").property("ADBE Position");

// Set property value
positionProp.setValue([960, 540]);

// Add keyframe
positionProp.setValueAtTime(0, [0, 0]);
positionProp.setValueAtTime(2, [1920, 1080]);

// Get keyframe information
var numKeys = positionProp.numKeys;
for (var i = 1; i <= numKeys; i++) {
    var keyTime = positionProp.keyTime(i);
    var keyValue = positionProp.keyValue(i);
}

// Set keyframe interpolation
positionProp.setInterpolationTypeAtKey(1, 
    KeyframeInterpolationType.BEZIER, 
    KeyframeInterpolationType.BEZIER
);

// Add expression
positionProp.expression = "wiggle(5, 50)";
positionProp.expressionEnabled = true;

// Remove all keyframes
while (positionProp.numKeys > 0) {
    positionProp.removeKey(1);
}
```

### Looping Through Items
```javascript
// Loop through all items in project
for (var i = 1; i <= app.project.numItems; i++) {
    var item = app.project.item(i);
    
    if (item instanceof CompItem) {
        // It's a composition
    } else if (item instanceof FootageItem) {
        // It's footage
    } else if (item instanceof FolderItem) {
        // It's a folder
    }
}

// Loop through layers in a composition
for (var i = 1; i <= comp.numLayers; i++) {
    var layer = comp.layer(i);
    
    if (layer instanceof AVLayer) {
        // Audio-visual layer
    } else if (layer instanceof TextLayer) {
        // Text layer
    } else if (layer instanceof ShapeLayer) {
        // Shape layer
    } else if (layer instanceof CameraLayer) {
        // Camera layer
    } else if (layer instanceof LightLayer) {
        // Light layer
    }
}

// Loop through selected layers
var selectedLayers = comp.selectedLayers;
for (var i = 0; i < selectedLayers.length; i++) {
    var layer = selectedLayers[i];
    // Work with selected layer
}

// Reverse loop (for deleting layers)
for (var i = comp.numLayers; i >= 1; i--) {
    var layer = comp.layer(i);
    if (layer.name.indexOf("Delete") !== -1) {
        layer.remove();
    }
}
```

### Working with Effects
```javascript
// Add effect by name
var effect = layer.property("Effects").addProperty("Gaussian Blur");

// Add effect by matchName (more reliable)
var effect = layer.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");

// Set effect property
effect.property("Blurriness").setValue(50);

// SCRIBE Installed Effects Context:
// The AI receives the 'installedEffects' object in the context containing all registered 
// native and third-party effects/plugins (like Sapphire, Red Giant, Trapcode, Element 3D) 
// grouped by category. Look at this registry to find the exact matchName of any plugin.

// Defensive Third-Party Parameter Modification:
// Because parameter names and indices can differ slightly between plugin versions, 
// always query and modify third-party effect parameters defensively. Use try-catch blocks 
// and property name or index fallbacks.
// Example:
var glow = layer.property("ADBE Effect Parade").addProperty("S_Glow");
if (glow) {
    var widthProp = null;
    try { widthProp = glow.property("Glow Width"); } catch(e) {
        try { widthProp = glow.property(3); } catch(e2) {} // fallback to index if name fails
    }
    if (widthProp) {
        widthProp.setValue(50);
    }
}

// Common effect matchNames:
// "ADBE Gaussian Blur 2" - Gaussian Blur
// "ADBE Box Blur2" - Fast Box Blur
// "ADBE Glo2" - Glow
// "ADBE Drop Shadow" - Drop Shadow
// "ADBE Color Correction" - Color Correction
// "ADBE Brightness & Contrast 2" - Brightness & Contrast
// "ADBE Curves3" - Curves
// "ADBE AUX CHANNEL EXTRACT" - Extract
// "ADBE Levels2" - Levels
// "ADBE Tint" - Tint
// "ADBE Fill" - Fill
// "ADBE Stroke" - Stroke


// Check if effect exists
var effects = layer.property("ADBE Effect Parade");
for (var i = 1; i <= effects.numProperties; i++) {
    if (effects.property(i).matchName === "ADBE Gaussian Blur 2") {
        $.writeln("Gaussian Blur found at index " + i);
    }
}

// Remove effect
effect.remove();

// Remove all effects
var effects = layer.property("ADBE Effect Parade");
while (effects.numProperties > 0) {
    effects.property(1).remove();
}
```

### Time and Markers
```javascript
// Get composition duration
var duration = comp.duration;

// Set current time
comp.time = 2.0; // 2 seconds

// Get frame rate
var frameRate = comp.frameRate;

// Convert time to frames
var frames = Math.floor(time * frameRate);

// Convert frames to time
var time = frames / frameRate;

// Add composition marker
var markerProp = comp.markerProperty;
var marker = new MarkerValue("Marker Comment");
marker.duration = 1.0;
marker.chapter = "Chapter 1";
marker.url = "http://example.com";
markerProp.setValueAtTime(2.0, marker);

// Add layer marker
var layerMarker = new MarkerValue("Layer Marker");
layer.property("ADBE Marker").setValueAtTime(1.0, layerMarker);

// Loop through markers
for (var i = 1; i <= markerProp.numKeys; i++) {
    var markerTime = markerProp.keyTime(i);
    var markerValue = markerProp.keyValue(i);
    $.writeln("Marker at " + markerTime + ": " + markerValue.comment);
}
```

### Working with Folders
```javascript
// Create folder in project
var folder = app.project.items.addFolder("My Folder");

// Move item to folder
item.parentFolder = folder;

// Check if item is in folder
if (item.parentFolder === folder) {
    // Item is in the folder
}

// Get all items in a folder
function getItemsInFolder(folder) {
    var items = [];
    for (var i = 1; i <= app.project.numItems; i++) {
        var item = app.project.item(i);
        if (item.parentFolder === folder) {
            items.push(item);
        }
    }
    return items;
}
```

### Pre-compositions
```javascript
// Create precomp from selected layers
var layersToPrecomp = comp.selectedLayers;
var precompName = "Precomp";

// Get layer indices (must be 1-based)
var layerIndices = [];
for (var i = 0; i < layersToPrecomp.length; i++) {
    layerIndices.push(layersToPrecomp[i].index);
}

// Move all attributes to precomp
var precomp = comp.layers.precompose(
    layerIndices,
    precompName,
    true        // moveAllAttributes
);

// Leave all attributes in main comp
var precomp = comp.layers.precompose(
    layerIndices,
    precompName,
    false
);
```

### Render Queue
```javascript
// Add comp to render queue
var renderItem = app.project.renderQueue.items.add(comp);

// Set output module settings
var outputModule = renderItem.outputModule(1);
outputModule.applyTemplate("Best Settings");

// Set output file
var file = new File("~/Desktop/output.mov");
outputModule.file = file;

// Set render settings
renderItem.applyTemplate("Best Settings");

// Start rendering
app.project.renderQueue.render();

// Check render status
if (app.project.renderQueue.canQueueInAME) {
    // Can send to Adobe Media Encoder
}
```

### File and Path Operations
```javascript
// Get project file
var projectFile = app.project.file;
if (projectFile) {
    var projectPath = projectFile.fsName;
    var projectFolder = projectFile.parent;
    var projectName = projectFile.name;
}

// File dialog
var file = File.openDialog("Select a file");
if (file) {
    // User selected a file
}

// Folder dialog
var folder = Folder.selectDialog("Select a folder");
if (folder) {
    // User selected a folder
}

// Save dialog
var file = File.saveDialog("Save file as");
if (file) {
    // User chose a save location
}

// Check if file exists
var file = new File("/path/to/file.txt");
if (file.exists) {
    // File exists
}

// Read file
file.open("r");
var content = file.read();
file.close();

// Write file
file.open("w");
file.write("Content to write");
file.close();

// Read file line by line
file.open("r");
while (!file.eof) {
    var line = file.readln();
    $.writeln(line);
}
file.close();

// Get all files in folder
var folder = new Folder("/path/to/folder");
var files = folder.getFiles();
for (var i = 0; i < files.length; i++) {
    $.writeln(files[i].name);
}

// Get files with extension
var pngFiles = folder.getFiles("*.png");
```

### User Interface
```javascript
// Simple alert
alert("Message to user");

// Confirm dialog
var result = confirm("Are you sure?");
if (result) {
    // User clicked OK
}

// Prompt dialog
var userInput = prompt("Enter a value:", "default value");
if (userInput !== null) {
    // User entered something
}

// Progress bar
var myPanel = new Window("palette", "Progress", undefined);
myPanel.progressBar = myPanel.add("progressbar", undefined, 0, 100);
myPanel.progressBar.preferredSize = [300, 20];
myPanel.show();

for (var i = 0; i < 100; i++) {
    myPanel.progressBar.value = i;
    app.refresh(); // Update UI
}
myPanel.close();
```

### Advanced UI Panel
```javascript
function createUI() {
    var myPanel = new Window("palette", "My Script Panel", undefined);
    myPanel.orientation = "column";
    myPanel.alignChildren = ["fill", "top"];
    myPanel.spacing = 10;
    myPanel.margins = 15;
    
    // Add button
    var btn = myPanel.add("button", undefined, "Click Me");
    btn.onClick = function() {
        alert("Button clicked!");
    };
    
    // Add text input
    var textGroup = myPanel.add("group");
    textGroup.add("statictext", undefined, "Name:");
    var textInput = textGroup.add("edittext", undefined, "");
    textInput.characters = 20;
    
    // Add dropdown
    var dropdownGroup = myPanel.add("group");
    dropdownGroup.add("statictext", undefined, "Choose:");
    var dropdown = dropdownGroup.add("dropdownlist", undefined, ["Option 1", "Option 2", "Option 3"]);
    dropdown.selection = 0;
    
    // Add checkbox
    var checkbox = myPanel.add("checkbox", undefined, "Enable feature");
    checkbox.value = true;
    
    // Add slider
    var sliderGroup = myPanel.add("group");
    sliderGroup.add("statictext", undefined, "Value:");
    var slider = sliderGroup.add("slider", undefined, 50, 0, 100);
    var sliderValue = sliderGroup.add("statictext", undefined, "50");
    slider.onChanging = function() {
        sliderValue.text = Math.round(slider.value);
    };
    
    // Add radio buttons
    var radioPanel = myPanel.add("panel", undefined, "Choose One");
    radioPanel.orientation = "column";
    radioPanel.alignChildren = "left";
    var radio1 = radioPanel.add("radiobutton", undefined, "Option A");
    var radio2 = radioPanel.add("radiobutton", undefined, "Option B");
    radio1.value = true;
    
    myPanel.center();
    myPanel.show();
}

createUI();
```

### Performance Optimization
```javascript
// Disable UI updates during script execution
app.beginSuppressDialogs();
// Your code here
app.endSuppressDialogs(false);

// Faster property access with matchNames
var TRANSFORM_GROUP = "ADBE Transform Group";
var POSITION = "ADBE Position";
var prop = layer.property(TRANSFORM_GROUP).property(POSITION);

// Cache frequently accessed objects
var comp = app.project.activeItem;
var layers = comp.layers;
var numLayers = comp.numLayers;

// Avoid repeated property lookups in loops
for (var i = 1; i <= numLayers; i++) {
    var layer = layers[i];
    var transform = layer.property(TRANSFORM_GROUP);
    var position = transform.property(POSITION);
    // Work with cached references
}

// Batch operations
app.beginUndoGroup("Batch Operation");
try {
    for (var i = 1; i <= comp.numLayers; i++) {
        // Perform operations
    }
} finally {
    app.endUndoGroup();
}
```

### Utility Functions
```javascript
// Get selected layers or all layers
function getSelectedLayersOrAll(comp) {
    var layers = comp.selectedLayers;
    if (layers.length === 0) {
        layers = [];
        for (var i = 1; i <= comp.numLayers; i++) {
            layers.push(comp.layer(i));
        }
    }
    return layers;
}

// Convert color from 0-255 to 0-1
function rgbTo01(r, g, b) {
    return [r/255, g/255, b/255];
}

// Convert color from 0-1 to 0-255
function rgb01To255(color) {
    return [
        Math.round(color[0] * 255),
        Math.round(color[1] * 255),
        Math.round(color[2] * 255)
    ];
}

// Get layer by name
function getLayerByName(comp, name) {
    for (var i = 1; i <= comp.numLayers; i++) {
        if (comp.layer(i).name === name) {
            return comp.layer(i);
        }
    }
    return null;
}

// Check if property can be keyed
function canBeKeyed(prop) {
    return prop.canVaryOverTime && !prop.isSeparationFollower;
}

// Safe property access
function safeGetProperty(layer, propertyPath) {
    try {
        var prop = layer;
        for (var i = 0; i < propertyPath.length; i++) {
            prop = prop.property(propertyPath[i]);
            if (!prop) return null;
        }
        return prop;
    } catch (e) {
        return null;
    }
}

// Get composition by name
function getCompByName(name) {
    for (var i = 1; i <= app.project.numItems; i++) {
        var item = app.project.item(i);
        if (item instanceof CompItem && item.name === name) {
            return item;
        }
    }
    return null;
}
```

---

## Intermediate Techniques

### Shape Layer Deep Dive
```javascript
// Create shape layer with rectangle
var shapeLayer = comp.layers.addShape();
shapeLayer.name = "Custom Shape";

// Access shape contents
var shapeGroup = shapeLayer.property("ADBE Root Vectors Group");

// Add a group
var group1 = shapeGroup.addProperty("ADBE Vector Group");
group1.name = "Shape Group 1";

// Add rectangle to group
var contents = group1.property("ADBE Vectors Group");
var rect = contents.addProperty("ADBE Vector Shape - Rect");
var rectSize = rect.property("ADBE Vector Rect Size");
rectSize.setValue([500, 300]);

// Add fill
var fill = contents.addProperty("ADBE Vector Graphic - Fill");
fill.property("ADBE Vector Fill Color").setValue([1, 0, 0]); // Red

// Add stroke
var stroke = contents.addProperty("ADBE Vector Graphic - Stroke");
stroke.property("ADBE Vector Stroke Color").setValue([0, 0, 1]); // Blue
stroke.property("ADBE Vector Stroke Width").setValue(10);

// Add trim paths
var trim = contents.addProperty("ADBE Vector Filter - Trim");
trim.property("ADBE Vector Trim Start").setValue(0);
var trimEnd = trim.property("ADBE Vector Trim End");
trimEnd.setValueAtTime(0, 0);
trimEnd.setValueAtTime(2, 100);

// Common shape matchNames:
// "ADBE Vector Shape - Rect" - Rectangle
// "ADBE Vector Shape - Ellipse" - Ellipse
// "ADBE Vector Shape - Star" - Polystar
// "ADBE Vector Shape - Group" - Path
// "ADBE Vector Graphic - Fill" - Fill
// "ADBE Vector Graphic - Stroke" - Stroke
// "ADBE Vector Graphic - G-Fill" - Gradient Fill
// "ADBE Vector Graphic - G-Stroke" - Gradient Stroke
// "ADBE Vector Filter - Trim" - Trim Paths
// "ADBE Vector Filter - Merge" - Merge Paths
// "ADBE Vector Filter - Offset" - Offset Paths
// "ADBE Vector Filter - PuckerBloat" - Pucker & Bloat
// "ADBE Vector Filter - RC" - Round Corners
// "ADBE Vector Filter - Roughen" - Roughen Edges
// "ADBE Vector Transform Group" - Transform (Shape)
```

### Expression Helpers & Common Expressions
```javascript
// Add wiggle expression
var positionProp = layer.property("ADBE Transform Group").property("ADBE Position");
positionProp.expression = "wiggle(5, 50)";
positionProp.expressionEnabled = true;

// Loop expression
positionProp.expression = "loopOut('cycle')"; // Loop forward
// Other loop types: 'pingpong', 'offset', 'continue'

// Freeze first frame
positionProp.expression = "valueAtTime(0)";

// Time remapping effects
layer.timeRemapEnabled = true;
var timeRemap = layer.property("ADBE Time Remapping");
timeRemap.expression = "time * 0.5"; // Half speed
// timeRemap.expression = "time * 2"; // Double speed
// timeRemap.expression = "Math.abs(time - inPoint - 2) + inPoint"; // Bounce

// Link to control layer
var controlLayerName = "Control";
positionProp.expression = 'thisComp.layer("' + controlLayerName + '").transform.position';

// Link to slider control
positionProp.expression = 'thisComp.layer("Control").effect("Slider Control")("Slider")';

// Add expression with layer reference
function addExpressionWithControl(targetProp, controlLayerName, effectName, propertyName) {
    var expr = 'thisComp.layer("' + controlLayerName + '").effect("' + effectName + '")("' + propertyName + '")';
    targetProp.expression = expr;
    targetProp.expressionEnabled = true;
}

// Common expression snippets
var expressions = {
    wiggle: "wiggle(frequency, amplitude)",
    loop: "loopOut(type = 'cycle', numKeyframes = 0)",
    time: "time", // Current time in seconds
    value: "value", // Current property value
    random: "random()", // Random value 0-1
    seedRandom: "seedRandom(index, timeless = false)",
    smooth: "smooth(width = .2, samples = 5, t = time)",
    linear: "linear(t, tMin, tMax, value1, value2)"
};
```

### JSON/Data Handling
```javascript
// ExtendScript has no native JSON.parse, use eval carefully
function parseJSON(str) {
    try {
        return eval('(' + str + ')');
    } catch (e) {
        alert("JSON Parse Error: " + e.toString());
        return null;
    }
}

// Simple JSON stringification (basic implementation)
function stringifyJSON(obj, indent) {
    indent = indent || "";
    var nextIndent = indent + "  ";
    
    if (obj === null) return "null";
    if (typeof obj === "undefined") return "undefined";
    if (typeof obj === "string") return '"' + obj.replace(/"/g, '\\"') + '"';
    if (typeof obj === "number" || typeof obj === "boolean") return String(obj);
    
    if (obj instanceof Array) {
        var arr = [];
        for (var i = 0; i < obj.length; i++) {
            arr.push(stringifyJSON(obj[i], nextIndent));
        }
        return "[\n" + nextIndent + arr.join(",\n" + nextIndent) + "\n" + indent + "]";
    }
    
    var props = [];
    for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
            props.push('"' + key + '": ' + stringifyJSON(obj[key], nextIndent));
        }
    }
    return "{\n" + nextIndent + props.join(",\n" + nextIndent) + "\n" + indent + "}";
}

// Read JSON data from file
function readJSONFile(filePath) {
    var file = new File(filePath);
    if (!file.exists) {
        alert("File not found: " + filePath);
        return null;
    }
    
    file.open("r");
    var content = file.read();
    file.close();
    
    return parseJSON(content);
}

// Write JSON data to file
function writeJSONFile(filePath, data) {
    var file = new File(filePath);
    file.open("w");
    file.write(stringifyJSON(data));
    file.close();
}

// Example: Data-driven animation
var data = readJSONFile("~/Desktop/animation_data.json");
if (data && data.textLayers) {
    for (var i = 0; i < data.textLayers.length; i++) {
        var textData = data.textLayers[i];
        var textLayer = comp.layers.addText(textData.text);
        var pos = textLayer.property("ADBE Transform Group").property("ADBE Position");
        pos.setValue([textData.x, textData.y]);
    }
}
```

### 3D Layer Operations
```javascript
// Enable 3D for layer
layer.threeDLayer = true;

// 3D position (as single property)
var position = layer.property("ADBE Transform Group").property("ADBE Position");
position.setValue([960, 540, 0]); // X, Y, Z

// Separate position dimensions
position.dimensionsSeparated = true;
var xPos = layer.property("ADBE Transform Group").property("ADBE Position_0");
var yPos = layer.property("ADBE Transform Group").property("ADBE Position_1");
var zPos = layer.property("ADBE Transform Group").property("ADBE Position_2");
xPos.setValue(960);
yPos.setValue(540);
zPos.setValue(-500);

// 3D rotation
var xRotation = layer.property("ADBE Transform Group").property("ADBE Rotate X");
var yRotation = layer.property("ADBE Transform Group").property("ADBE Rotate Y");
var zRotation = layer.property("ADBE Transform Group").property("ADBE Rotate Z");
xRotation.setValue(45);
yRotation.setValue(30);

// Orientation (different from rotation)
var orientation = layer.property("ADBE Transform Group").property("ADBE Orientation");
orientation.setValue([45, 30, 0]); // X, Y, Z degrees

// 3D matchNames:
// "ADBE Rotate X" - X Rotation
// "ADBE Rotate Y" - Y Rotation  
// "ADBE Rotate Z" - Z Rotation
// "ADBE Orientation" - Orientation
// "ADBE Position_0" - X Position (when separated)
// "ADBE Position_1" - Y Position (when separated)
// "ADBE Position_2" - Z Position (when separated)

// Add camera
var cameraPosition = [comp.width/2, comp.height/2, -1000];
var camera = comp.layers.addCamera("Main Camera", cameraPosition);
camera.property("ADBE Transform Group").property("ADBE Position").setValue(cameraPosition);

// Camera properties
var cameraOptions = camera.property("ADBE Camera Options Group");
var zoom = cameraOptions.property("ADBE Camera Zoom");
zoom.setValue(2000);

var depthOfField = cameraOptions.property("ADBE Camera Depth of Field");
depthOfField.setValue(1); // Enable

var focusDistance = cameraOptions.property("ADBE Camera Focus Distance");
focusDistance.setValue(1000);

// Add light
var lightPosition = [comp.width/2, comp.height/2, -500];
var light = comp.layers.addLight("Main Light", lightPosition);

// Light types
light.lightType = LightType.SPOT;
// LightType.PARALLEL, LightType.POINT, LightType.AMBIENT, LightType.SPOT

// Light properties
var lightOptions = light.property("ADBE Light Options Group");
var intensity = lightOptions.property("ADBE Light Intensity");
intensity.setValue(100);

var coneAngle = lightOptions.property("ADBE Light Cone Angle");
coneAngle.setValue(90);

var coneFeather = lightOptions.property("ADBE Light Cone Feather 2");
coneFeather.setValue(50);

var color = lightOptions.property("ADBE Light Color");
color.setValue([1, 1, 1]);

var castsShadows = lightOptions.property("ADBE Light Casts Shadows");
castsShadows.setValue(1);
```

### Mask Operations
```javascript
// Create a mask with vertices
var maskShape = new Shape();
maskShape.vertices = [[100, 100], [500, 100], [500, 400], [100, 400]]; // Rectangle
maskShape.inTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
maskShape.outTangents = [[0, 0], [0, 0], [0, 0], [0, 0]];
maskShape.closed = true;

// Add mask to layer
var maskGroup = layer.property("ADBE Mask Parade");
var mask = maskGroup.addProperty("ADBE Mask Atom");
mask.property("ADBE Mask Shape").setValue(maskShape);

// Set mask properties
mask.property("ADBE Mask Feather").setValue([10, 10]); // Pixels
mask.property("ADBE Mask Opacity").setValue(100); // Percentage
mask.property("ADBE Mask Offset").setValue([0, 0]);

// Mask modes
mask.maskMode = MaskMode.ADD;
// MaskMode.NONE - No mask
// MaskMode.ADD - Add
// MaskMode.SUBTRACT - Subtract
// MaskMode.INTERSECT - Intersect
// MaskMode.LIGHTEN - Lighten
// MaskMode.DARKEN - Darken
// MaskMode.DIFFERENCE - Difference

// Invert mask
mask.inverted = true;

// Animate mask path
var maskPath = mask.property("ADBE Mask Shape");
var shape1 = new Shape();
shape1.vertices = [[100, 100], [200, 100], [200, 200], [100, 200]];
shape1.closed = true;

var shape2 = new Shape();
shape2.vertices = [[300, 300], [600, 300], [600, 600], [300, 600]];
shape2.closed = true;

maskPath.setValueAtTime(0, shape1);
maskPath.setValueAtTime(2, shape2);

// Create circular mask
function createCircleMask(layer, centerX, centerY, radius, numPoints) {
    numPoints = numPoints || 100;
    var vertices = [];
    var inTangents = [];
    var outTangents = [];
    
    for (var i = 0; i < numPoints; i++) {
        var angle = (i / numPoints) * Math.PI * 2;
        var x = centerX + Math.cos(angle) * radius;
        var y = centerY + Math.sin(angle) * radius;
        vertices.push([x, y]);
        
        // Calculate tangents for smooth circle
        var tangentLength = radius * 0.552;
        var tx = Math.sin(angle) * tangentLength;
        var ty = -Math.cos(angle) * tangentLength;
        inTangents.push([-tx, -ty]);
        outTangents.push([tx, ty]);
    }
    
    var shape = new Shape();
    shape.vertices = vertices;
    shape.inTangents = inTangents;
    shape.outTangents = outTangents;
    shape.closed = true;
    
    var mask = layer.property("ADBE Mask Parade").addProperty("ADBE Mask Atom");
    mask.property("ADBE Mask Shape").setValue(shape);
    
    return mask;
}

// Mask expansion
mask.property("ADBE Mask Offset").setValue([20, 20]); // Expand by 20 pixels
```

### Advanced Keyframe Interpolation
```javascript
// Set keyframe ease (velocity control)
var prop = layer.property("ADBE Transform Group").property("ADBE Position");
prop.setValueAtTime(0, [0, 540]);
prop.setValueAtTime(2, [1920, 540]);

// Ease in and out
var keyIn = new KeyframeEase(0, 75);   // speed (0=stop), influence (0-100)
var keyOut = new KeyframeEase(0, 75);
prop.setTemporalEaseAtKey(2, [keyIn, keyIn], [keyOut, keyOut]); // For 2D value

// For 1D properties (like opacity)
var opacity = layer.property("ADBE Transform Group").property("ADBE Opacity");
opacity.setValueAtTime(0, 0);
opacity.setValueAtTime(1, 100);
opacity.setTemporalEaseAtKey(2, [keyIn], [keyOut]);

// Different easing for each dimension (position)
var easeInX = new KeyframeEase(0, 50);
var easeInY = new KeyframeEase(0, 75);
var easeOutX = new KeyframeEase(0, 50);
var easeOutY = new KeyframeEase(0, 75);
prop.setTemporalEaseAtKey(2, [easeInX, easeInY], [easeOutX, easeOutY]);

// Set spatial interpolation (for position paths)
// This controls the shape of the motion path
prop.setSpatialTangentsAtKey(2,
    [-100, 0],     // inTangent (previous keyframe direction)
    [100, 0]       // outTangent (next keyframe direction)
);

// Create linear motion path
prop.setSpatialTangentsAtKey(2, [0, 0], [0, 0]);

// Auto-bezier spatial interpolation
prop.setSpatialAutoBezierAtKey(2, true);

// Roving keyframes (for smooth motion)
// Allows AE to adjust timing for constant speed
prop.setRovingAtKey(2, true);

// Hold keyframes (step interpolation)
prop.setInterpolationTypeAtKey(1,
    KeyframeInterpolationType.HOLD,
    KeyframeInterpolationType.HOLD
);

// Linear interpolation
prop.setInterpolationTypeAtKey(1,
    KeyframeInterpolationType.LINEAR,
    KeyframeInterpolationType.LINEAR
);

// Bezier interpolation (smooth)
prop.setInterpolationTypeAtKey(1,
    KeyframeInterpolationType.BEZIER,
    KeyframeInterpolationType.BEZIER
);

// Set all keyframes to easy ease
function setAllKeyframesEasyEase(prop) {
    var easeIn = new KeyframeEase(0, 33);
    var easeOut = new KeyframeEase(0, 33);
    
    for (var i = 1; i <= prop.numKeys; i++) {
        if (prop.keyValue(i).length === 2) {
            // 2D property
            prop.setTemporalEaseAtKey(i, [easeIn, easeIn], [easeOut, easeOut]);
        } else if (prop.keyValue(i).length === 3) {
            // 3D property
            prop.setTemporalEaseAtKey(i, [easeIn, easeIn, easeIn], [easeOut, easeOut, easeOut]);
        } else {
            // 1D property
            prop.setTemporalEaseAtKey(i, [easeIn], [easeOut]);
        }
    }
}
```

### Project Management & Organization
```javascript
// Reduce project (remove unused footage)
app.project.reduceProject();

// Consolidate duplicates
app.project.consolidateFootage();

// Collect files to folder
function collectFiles(destinationFolder) {
    // Note: This creates a copy of the project with collected files
    // The actual file collection happens through File > Dependencies > Collect Files
    
    // Save current project
    if (!app.project.file) {
        alert("Please save the project first");
        return;
    }
    
    var currentFile = app.project.file;
    var collectFolder = new Folder(destinationFolder);
    
    if (!collectFolder.exists) {
        collectFolder.create();
    }
    
    // Copy project to collect folder
    var newProjectFile = new File(collectFolder.fsName + "/" + currentFile.name);
    currentFile.copy(newProjectFile);
}

// Project settings
app.project.bitsPerChannel = 16; // 8, 16, or 32
app.project.timeDisplayType = TimeDisplayType.FRAMES; 
// TimeDisplayType.FRAMES or TimeDisplayType.TIMECODE

// Linear color working space
app.project.linearBlending = true;

// Save project
var saveFile = new File("~/Desktop/MyProject.aep");
app.project.save(saveFile);

// Close project
app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES);
// CloseOptions.SAVE_CHANGES or CloseOptions.PROMPT_TO_SAVE_CHANGES

// Get project info
var projectInfo = {
    name: app.project.file ? app.project.file.name : "Untitled",
    numItems: app.project.numItems,
    activeItem: app.project.activeItem ? app.project.activeItem.name : "None",
    renderQueue: app.project.renderQueue.numItems,
    bitsPerChannel: app.project.bitsPerChannel,
    timeDisplayType: app.project.timeDisplayType
};

// Remove unused footage
function removeUnusedFootage() {
    var removed = 0;
    
    // Loop backwards when removing items
    for (var i = app.project.numItems; i >= 1; i--) {
        var item = app.project.item(i);
        
        // Check if footage item and not used in any comp
        if (item instanceof FootageItem && item.usedIn.length === 0) {
            item.remove();
            removed++;
        }
    }
    
    alert("Removed " + removed + " unused footage item(s)");
}
```

---

## Advanced Operations

### ScriptUI Best Practices

#### Window Types
```javascript
// Palette window (dockable, stays on top)
var palette = new Window("palette", "My Palette", undefined);

// Dialog window (modal, blocks other windows)
var dialog = new Window("dialog", "My Dialog", undefined);

// Floating window (non-modal, can go behind)
var floating = new Window("window", "My Window", undefined);
```

#### Dockable Panels
```javascript
// Create dockable panel
function createDockablePanel(thisObj) {
    var panel = (thisObj instanceof Panel) ? thisObj : new Window("palette", "My Panel", undefined);
    
    panel.orientation = "column";
    panel.alignChildren = ["fill", "top"];
    
    // Add UI elements
    var btn = panel.add("button", undefined, "Do Something");
    btn.onClick = function() {
        // Button action
    };
    
    // Make it dockable
    if (panel instanceof Window) {
        panel.show();
    } else {
        panel.layout.layout(true);
    }
    
    return panel;
}

// Call with: createDockablePanel(this);
```

#### Resource Strings for UI
```javascript
// Using resource strings for complex layouts
var resourceString = 
    "palette { \
        orientation: 'column', \
        alignChildren: ['fill', 'top'], \
        text: 'My Script', \
        btnGroup: Group { \
            orientation: 'row', \
            btn1: Button { text: 'Button 1' }, \
            btn2: Button { text: 'Button 2' } \
        }, \
        inputGroup: Group { \
            orientation: 'row', \
            label: StaticText { text: 'Input:' }, \
            input: EditText { characters: 20 } \
        } \
    }";

var win = new Window(resourceString);
win.btnGroup.btn1.onClick = function() { alert("Button 1 clicked"); };
win.center();
win.show();
```

#### Event Handling Patterns
```javascript
function createUIWithEvents() {
    var win = new Window("palette", "Event Handling", undefined);
    win.orientation = "column";
    
    // Text input with validation
    var input = win.add("edittext", undefined, "");
    input.characters = 10;
    
    input.onChange = function() {
        // Triggered on every character change
        $.writeln("Changed: " + this.text);
    };
    
    input.onChanging = function() {
        // Triggered during typing
        $.writeln("Changing: " + this.text);
    };
    
    // Button with multiple actions
    var btn = win.add("button", undefined, "Process");
    btn.onClick = function() {
        if (input.text === "") {
            alert("Please enter a value");
            return;
        }
        processData(input.text);
    };
    
    // Dropdown with change handler
    var dropdown = win.add("dropdownlist", undefined, ["Option A", "Option B", "Option C"]);
    dropdown.selection = 0;
    dropdown.onChange = function() {
        $.writeln("Selected: " + this.selection.text);
    };
    
    // Window close event
    win.onClose = function() {
        $.writeln("Window closed");
        return true; // Allow close
    };
    
    win.show();
}
```

#### UI Persistence (Saving Panel State)
```javascript
function createPersistentUI() {
    var win = new Window("palette", "Persistent Settings", undefined);
    
    // Settings file
    var settingsFile = new File(Folder.userData.fsName + "/MyScriptSettings.json");
    
    // Load saved settings
    function loadSettings() {
        if (settingsFile.exists) {
            settingsFile.open("r");
            var content = settingsFile.read();
            settingsFile.close();
            return parseJSON(content) || {};
        }
        return {};
    }
    
    // Save settings
    function saveSettings(settings) {
        settingsFile.open("w");
        settingsFile.write(stringifyJSON(settings));
        settingsFile.close();
    }
    
    var settings = loadSettings();
    
    // Create UI elements with saved values
    var input = win.add("edittext", undefined, settings.inputValue || "");
    input.characters = 20;
    
    var checkbox = win.add("checkbox", undefined, "Enable Feature");
    checkbox.value = settings.checkboxValue || false;
    
    // Save on close
    win.onClose = function() {
        var newSettings = {
            inputValue: input.text,
            checkboxValue: checkbox.value
        };
        saveSettings(newSettings);
        return true;
    };
    
    win.show();
}
```

### Marker-Based Automation
```javascript
// Process marker commands
function processMarkerActions(comp) {
    var markers = comp.markerProperty;
    
    for (var i = 1; i <= markers.numKeys; i++) {
        var time = markers.keyTime(i);
        var marker = markers.keyValue(i);
        var comment = marker.comment;
        
        // Parse commands from marker comments
        if (comment.indexOf("ADD_TEXT:") === 0) {
            var text = comment.substring(9);
            var textLayer = comp.layers.addText(text);
            textLayer.startTime = time;
            
        } else if (comment.indexOf("ADD_SOLID:") === 0) {
            var colorStr = comment.substring(10);
            var rgb = colorStr.split(",");
            var solid = comp.layers.addSolid(
                [parseFloat(rgb[0]), parseFloat(rgb[1]), parseFloat(rgb[2])],
                "Auto Solid",
                comp.width,
                comp.height,
                1.0
            );
            solid.startTime = time;
            
        } else if (comment.indexOf("SNAPSHOT") === 0) {
            // Take snapshot at this time
            comp.time = time;
            // Trigger snapshot action
        }
    }
}

// Example usage
var comp = app.project.activeItem;
if (comp && comp instanceof CompItem) {
    processMarkerActions(comp);
}
```

### Data-Driven Animation Workflows
```javascript
// Create animation from CSV data
function animateFromCSV(csvFilePath, comp) {
    var file = new File(csvFilePath);
    if (!file.exists) {
        alert("CSV file not found");
        return;
    }
    
    file.open("r");
    var headers = file.readln().split(",");
    
    while (!file.eof) {
        var line = file.readln();
        if (line === "") continue;
        
        var values = line.split(",");
        var data = {};
        
        for (var i = 0; i < headers.length; i++) {
            data[headers[i].trim()] = values[i].trim();
        }
        
        // Create layer based on CSV data
        if (data.type === "text") {
            var textLayer = comp.layers.addText(data.content);
            var pos = textLayer.property("ADBE Transform Group").property("ADBE Position");
            pos.setValue([parseFloat(data.x), parseFloat(data.y)]);
            textLayer.startTime = parseFloat(data.time);
        }
    }
    
    file.close();
}

// Batch processing multiple compositions
function batchProcessComps(processingFunction) {
    for (var i = 1; i <= app.project.numItems; i++) {
        var item = app.project.item(i);
        
        if (item instanceof CompItem) {
            $.writeln("Processing: " + item.name);
            processingFunction(item);
        }
    }
}

// Example: Add fade in/out to all comps
batchProcessComps(function(comp) {
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        var opacity = layer.property("ADBE Transform Group").property("ADBE Opacity");
        
        // Fade in
        opacity.setValueAtTime(layer.inPoint, 0);
        opacity.setValueAtTime(layer.inPoint + 0.5, 100);
        
        // Fade out
        opacity.setValueAtTime(layer.outPoint - 0.5, 100);
        opacity.setValueAtTime(layer.outPoint, 0);
    }
});
```

### Template-Based Composition Creation
```javascript
// Create composition from template
function createFromTemplate(templateComp, newName, customData) {
    // Duplicate template
    var newComp = templateComp.duplicate();
    newComp.name = newName;
    
    // Replace placeholder text
    for (var i = 1; i <= newComp.numLayers; i++) {
        var layer = newComp.layer(i);
        
        if (layer instanceof TextLayer) {
            var textProp = layer.property("ADBE Text Properties").property("ADBE Text Document");
            var textDoc = textProp.value;
            
            // Replace placeholders
            for (var key in customData) {
                if (textDoc.text.indexOf("{{" + key + "}}") !== -1) {
                    textDoc.text = textDoc.text.replace("{{" + key + "}}", customData[key]);
                    textProp.setValue(textDoc);
                }
            }
        }
    }
    
    return newComp;
}

// Usage
var template = getCompByName("TEMPLATE_LowerThird");
var newComp = createFromTemplate(template, "Client Name Lower Third", {
    name: "John Doe",
    title: "CEO",
    company: "Acme Corp"
});
```

### Version Compatibility
```javascript
// Check After Effects version
var appVersion = parseFloat(app.version);

if (appVersion >= 16.0) {
    // Essential Graphics features available (CC 2019+)
    // Motion Graphics Templates
    var comp = app.project.activeItem;
    if (comp instanceof CompItem) {
        // Check if comp is a Motion Graphics Template
        if (comp.motionGraphicsTemplateName) {
            $.writeln("This is an MOGRT: " + comp.motionGraphicsTemplateName);
        }
    }
}

if (appVersion >= 17.0) {
    // Features in CC 2020+
    // Enhanced shape layer features
}

if (appVersion >= 18.0) {
    // Features in CC 2021+
    // Multi-frame rendering
}

if (appVersion >= 22.0) {
    // Features in CC 2022+
    // 3D improvements
}

// Version-specific feature detection
function hasFeature(featureName) {
    switch (featureName) {
        case "mogrt":
            return appVersion >= 16.0;
        case "multiframe":
            return appVersion >= 18.0;
        case "advancedText":
            return appVersion >= 17.5;
        default:
            return false;
    }
}
```

---

## Common Pitfalls & Gotchas

### Index Issues
```javascript
// GOTCHA: Indices are 1-based, not 0-based
var firstLayer = comp.layer(1); // NOT comp.layer(0)
var firstItem = app.project.item(1); // NOT app.project.item(0)

// GOTCHA: selectedLayers returns array (0-based), but layer() uses 1-based
var selected = comp.selectedLayers; // Returns 0-based array
for (var i = 0; i < selected.length; i++) {
    var layer = selected[i]; // Array access is 0-based
    $.writeln(layer.index); // But layer.index is 1-based
}

// To get layer by index from composition:
var layer = comp.layer(1); // 1-based
```

### Property Value Issues
```javascript
// GOTCHA: Property values might be null or undefined
var pos = layer.property("ADBE Transform Group").property("ADBE Position");
var value = pos.value;

if (value === null || value === undefined) {
    $.writeln("Property has no value");
    // Handle appropriately
}

// GOTCHA: Check if property exists before accessing
var prop = layer.property("ADBE Effect Parade").property("Gaussian Blur");
if (prop) {
    // Effect exists
} else {
    $.writeln("Effect not found");
}
```

### Time vs Frame Confusion
```javascript
// GOTCHA: Time is in seconds, not frames
var comp = app.project.activeItem;
var frameRate = comp.frameRate;

// Convert frame to time
var frame = 75;
var time = frame / frameRate; // In seconds

// Convert time to frame
var timeInSeconds = 2.5;
var frameNumber = Math.round(timeInSeconds * frameRate);

// Set layer in point (use time, not frames)
layer.inPoint = 2.0; // 2 seconds, not frame 2
```

### Color Value Range
```javascript
// GOTCHA: Colors are 0-1, not 0-255
var red = [1, 0, 0]; // NOT [255, 0, 0]

// Convert 0-255 to 0-1
function rgbTo01(r, g, b) {
    return [r/255, g/255, b/255];
}

// Convert 0-1 to 0-255
function rgb01To255(color) {
    return [
        Math.round(color[0] * 255),
        Math.round(color[1] * 255),
        Math.round(color[2] * 255)
    ];
}
```

### Property Name vs MatchName
```javascript
// GOTCHA: Property names are language-dependent, matchNames are not
// BAD: Using property name (fails in non-English AE)
var pos = layer.property("Transform").property("Position");

// GOOD: Using matchName (works in all languages)
var pos = layer.property("ADBE Transform Group").property("ADBE Position");

// Always use matchNames for reliability
```

### Layer Removal in Loops
```javascript
// GOTCHA: Removing layers while looping forward causes skipping
// BAD:
for (var i = 1; i <= comp.numLayers; i++) {
    comp.layer(i).remove(); // Indices shift, layers get skipped
}

// GOOD: Loop backwards when removing
for (var i = comp.numLayers; i >= 1; i--) {
    comp.layer(i).remove(); // Safe
}
```

### Expression Syntax
```javascript
// GOTCHA: Expressions are strings, watch escaping
// BAD:
layer.property("Position").expression = "thisComp.layer("Control").transform.position";

// GOOD:
layer.property("ADBE Position").expression = 'thisComp.layer("Control").transform.position';
// Use single quotes for string, double quotes inside

// Or escape properly:
layer.property("ADBE Position").expression = "thisComp.layer(\"Control\").transform.position";
```

### Undo Group Management
```javascript
// GOTCHA: Always close undo groups, even on error
// BAD:
app.beginUndoGroup("My Script");
// ... code that might throw error
app.endUndoGroup(); // Never reached if error occurs

// GOOD:
app.beginUndoGroup("My Script");
try {
    // ... your code
} catch (e) {
    alert("Error: " + e.toString());
} finally {
    app.endUndoGroup(); // Always executed
}
```

### Array Methods
```javascript
// GOTCHA: ExtendScript doesn't have modern array methods
// These DON'T work: forEach, map, filter, reduce, find

// BAD:
layers.forEach(function(layer) { // forEach doesn't exist in ES3
    // ...
});

// GOOD: Use traditional for loops
for (var i = 0; i < layers.length; i++) {
    var layer = layers[i];
    // ...
}
```

---

## Real-World Examples

### Example 1: Auto-Align Text Layers in Grid
```javascript
(function() {
    app.beginUndoGroup("Align Text Grid");
    
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            alert("Please select a composition");
            return;
        }
        
        var layers = comp.selectedLayers;
        if (layers.length === 0) {
            alert("Please select text layers");
            return;
        }
        
        // Grid settings
        var columns = parseInt(prompt("Number of columns:", "3"));
        var spacing = 100;
        var startX = 100;
        var startY = 100;
        
        for (var i = 0; i < layers.length; i++) {
            var row = Math.floor(i / columns);
            var col = i % columns;
            
            var x = startX + (col * spacing);
            var y = startY + (row * spacing);
            
            var pos = layers[i].property("ADBE Transform Group").property("ADBE Position");
            pos.setValue([x, y]);
        }
        
        alert("Aligned " + layers.length + " layers in " + columns + " columns");
        
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
})();
```

### Example 2: Batch Apply Effect with Random Values
```javascript
(function() {
    app.beginUndoGroup("Random Effect Values");
    
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            alert("Please select a composition");
            return;
        }
        
        var layers = getSelectedLayersOrAll(comp);
        
        for (var i = 0; i < layers.length; i++) {
            // Add Gaussian Blur
            var blur = layers[i].property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
            
            // Random blur amount between 5 and 50
            var randomBlur = 5 + Math.random() * 45;
            blur.property("ADBE Gaussian Blur 2-0001").setValue(randomBlur);
            
            // Add Glow
            var glow = layers[i].property("ADBE Effect Parade").addProperty("ADBE Glo2");
            
            // Random glow threshold
            var randomThreshold = 50 + Math.random() * 50;
            glow.property("ADBE Glo2-0001").setValue(randomThreshold);
        }
        
        alert("Applied effects to " + layers.length + " layers");
        
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
    
    function getSelectedLayersOrAll(comp) {
        var layers = comp.selectedLayers;
        if (layers.length === 0) {
            layers = [];
            for (var i = 1; i <= comp.numLayers; i++) {
                layers.push(comp.layer(i));
            }
        }
        return layers;
    }
})();
```

### Example 3: Create Lower Third Template
```javascript
(function() {
    app.beginUndoGroup("Create Lower Third");
    
    try {
        if (!app.project) {
            alert("Please open a project");
            return;
        }
        
        // Get user input
        var name = prompt("Enter name:", "John Doe");
        var title = prompt("Enter title:", "Creative Director");
        
        if (!name || !title) return;
        
        // Create composition
        var comp = app.project.items.addComp("Lower Third - " + name, 1920, 1080, 1.0, 5, 30);
        
        // Create background solid
        var bg = comp.layers.addSolid([0.1, 0.1, 0.1], "BG", 1920, 200, 1.0);
        var bgPos = bg.property("ADBE Transform Group").property("ADBE Position");
        bgPos.setValue([960, 980]);
        
        // Animate background in
        var bgScale = bg.property("ADBE Transform Group").property("ADBE Scale");
        bgScale.setValueAtTime(0, [0, 100]);
        bgScale.setValueAtTime(0.3, [100, 100]);
        
        // Create name text
        var nameLayer = comp.layers.addText(name);
        var nameProp = nameLayer.property("ADBE Text Properties").property("ADBE Text Document");
        var nameDoc = nameProp.value;
        nameDoc.fontSize = 60;
        nameDoc.fillColor = [1, 1, 1];
        nameDoc.font = "Arial-BoldMT";
        nameDoc.justification = ParagraphJustification.LEFT_JUSTIFY;
        nameProp.setValue(nameDoc);
        
        var namePos = nameLayer.property("ADBE Transform Group").property("ADBE Position");
        namePos.setValue([100, 930]);
        
        // Animate name in
        namePos.setValueAtTime(0.2, [100, 930]);
        namePos.setValueAtTime(0.5, [100, 930]);
        var nameOpacity = nameLayer.property("ADBE Transform Group").property("ADBE Opacity");
        nameOpacity.setValueAtTime(0.2, 0);
        nameOpacity.setValueAtTime(0.5, 100);
        
        // Create title text
        var titleLayer = comp.layers.addText(title);
        var titleProp = titleLayer.property("ADBE Text Properties").property("ADBE Text Document");
        var titleDoc = titleProp.value;
        titleDoc.fontSize = 36;
        titleDoc.fillColor = [0.8, 0.8, 0.8];
        titleDoc.font = "Arial";
        titleDoc.justification = ParagraphJustification.LEFT_JUSTIFY;
        titleProp.setValue(titleDoc);
        
        var titlePos = titleLayer.property("ADBE Transform Group").property("ADBE Position");
        titlePos.setValue([100, 990]);
        
        // Animate title in
        titlePos.setValueAtTime(0.3, [100, 990]);
        titlePos.setValueAtTime(0.6, [100, 990]);
        var titleOpacity = titleLayer.property("ADBE Transform Group").property("ADBE Opacity");
        titleOpacity.setValueAtTime(0.3, 0);
        titleOpacity.setValueAtTime(0.6, 100);
        
        alert("Lower third created successfully!");
        
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
})();
```

### Example 4: Generate Countdown Timer
```javascript
(function() {
    app.beginUndoGroup("Create Countdown");
    
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            alert("Please select a composition");
            return;
        }
        
        // Get countdown duration
        var seconds = parseInt(prompt("Countdown duration (seconds):", "10"));
        if (!seconds) return;
        
        // Create text layer
        var textLayer = comp.layers.addText("10");
        var textProp = textLayer.property("ADBE Text Properties").property("ADBE Text Document");
        var textDoc = textProp.value;
        textDoc.fontSize = 200;
        textDoc.fillColor = [1, 1, 1];
        textDoc.font = "Arial-BoldMT";
        textDoc.justification = ParagraphJustification.CENTER_JUSTIFY;
        textProp.setValue(textDoc);
        
        // Center text
        var pos = textLayer.property("ADBE Transform Group").property("ADBE Position");
        pos.setValue([comp.width/2, comp.height/2]);
        
        // Add countdown expression
        var sourceTextProp = textLayer.property("ADBE Text Properties").property("ADBE Text Document");
        sourceTextProp.expression = 
            'var countdownFrom = ' + seconds + ';\n' +
            'var timeLeft = countdownFrom - time;\n' +
            'if (timeLeft <= 0) {\n' +
            '    "GO!";\n' +
            '} else {\n' +
            '    Math.ceil(timeLeft).toString();\n' +
            '}';
        
        // Add scale animation on each second
        var scale = textLayer.property("ADBE Transform Group").property("ADBE Scale");
        for (var i = 0; i <= seconds; i++) {
            scale.setValueAtTime(i, [120, 120]);
            scale.setValueAtTime(i + 0.2, [100, 100]);
        }
        
        alert("Countdown timer created!");
        
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
})();
```

### Example 5: Export Composition Screenshots
```javascript
(function() {
    app.beginUndoGroup("Export Screenshots");
    
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            alert("Please select a composition");
            return;
        }
        
        // Select output folder
        var outputFolder = Folder.selectDialog("Select output folder");
        if (!outputFolder) return;
        
        // Get time points
        var interval = parseFloat(prompt("Snapshot interval (seconds):", "1"));
        var numSnapshots = Math.floor(comp.duration / interval);
        
        var confirm = window.confirm("This will create " + numSnapshots + " snapshots. Continue?");
        if (!confirm) return;
        
        // Create progress window
        var progressWin = new Window("palette", "Exporting Screenshots", undefined);
        progressWin.progress = progressWin.add("progressbar", undefined, 0, numSnapshots);
        progressWin.progress.preferredSize = [300, 20];
        progressWin.show();
        
        // Add comp to render queue
        for (var i = 0; i < numSnapshots; i++) {
            var time = i * interval;
            comp.time = time;
            
            var renderItem = app.project.renderQueue.items.add(comp);
            var outputModule = renderItem.outputModule(1);
            
            // Set output as PNG sequence (single frame)
            outputModule.applyTemplate("PNG Sequence");
            
            var fileName = comp.name + "_" + zeroPad(i, 4) + ".png";
            var outputFile = new File(outputFolder.fsName + "/" + fileName);
            outputModule.file = outputFile;
            
            // Set time span to single frame
            renderItem.timeSpanStart = time;
            renderItem.timeSpanDuration = 1 / comp.frameRate;
            
            progressWin.progress.value = i + 1;
        }
        
        progressWin.close();
        
        // Start rendering
        app.project.renderQueue.render();
        
        alert("Screenshots exported to:\n" + outputFolder.fsName);
        
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
    
    function zeroPad(num, places) {
        var str = num.toString();
        while (str.length < places) {
            str = "0" + str;
        }
        return str;
    }
})();
```

---

## Reference Tables

### Common MatchNames Reference

#### Transform Properties
- Transform Group: `"ADBE Transform Group"`
- Anchor Point: `"ADBE Anchor Point"`
- Position: `"ADBE Position"`
- Position (Separated X): `"ADBE Position_0"`
- Position (Separated Y): `"ADBE Position_1"`
- Position (Separated Z): `"ADBE Position_2"`
- Scale: `"ADBE Scale"`
- Rotation: `"ADBE Rotate Z"`
- X Rotation: `"ADBE Rotate X"`
- Y Rotation: `"ADBE Rotate Y"`
- Orientation: `"ADBE Orientation"`
- Opacity: `"ADBE Opacity"`

#### Layer Properties
- Effects: `"ADBE Effect Parade"`
- Masks: `"ADBE Mask Parade"`
- Text Properties: `"ADBE Text Properties"`
- Marker: `"ADBE Marker"`
- Time Remap: `"ADBE Time Remapping"`
- Audio: `"ADBE Audio Group"`
- Audio Levels: `"ADBE Audio Levels"`

#### Text Properties
- Source Text: `"ADBE Text Document"`
- Path Options: `"ADBE Text Path Options"`
- More Options: `"ADBE Text More Options"`
- Animators: `"ADBE Text Animators"`

#### Shape Layer Properties
- Root Vectors Group: `"ADBE Root Vectors Group"`
- Vector Group: `"ADBE Vector Group"`
- Rectangle: `"ADBE Vector Shape - Rect"`
- Ellipse: `"ADBE Vector Shape - Ellipse"`
- Polystar: `"ADBE Vector Shape - Star"`
- Path: `"ADBE Vector Shape - Group"`
- Fill: `"ADBE Vector Graphic - Fill"`
- Stroke: `"ADBE Vector Graphic - Stroke"`
- Gradient Fill: `"ADBE Vector Graphic - G-Fill"`
- Gradient Stroke: `"ADBE Vector Graphic - G-Stroke"`
- Trim Paths: `"ADBE Vector Filter - Trim"`
- Merge Paths: `"ADBE Vector Filter - Merge"`

#### Common Effects MatchNames
- Gaussian Blur: `"ADBE Gaussian Blur 2"`
- Fast Box Blur: `"ADBE Box Blur2"`
- Glow: `"ADBE Glo2"`
- Drop Shadow: `"ADBE Drop Shadow"`
- Color Correction: `"ADBE Color Correction"`
- Brightness & Contrast: `"ADBE Brightness & Contrast 2"`
- Curves: `"ADBE Curves3"`
- Levels: `"ADBE Levels2"`
- Hue/Saturation: `"ADBE HUE SATURATION"`
- Tint: `"ADBE Tint"`
- Fill: `"ADBE Fill"`
- Stroke: `"ADBE Stroke"`
- CC Radial Fast Blur: `"ADBE REEL RadialFastBlur"`
- Sharpen: `"ADBE Sharpen"`

### Error Handling Best Practices
```javascript
// Comprehensive error handling template
(function() {
    app.beginUndoGroup("My Script");
    
    try {
        // Validate environment
        if (!(app instanceof Application)) {
            throw new Error("After Effects not available");
        }
        
        if (!app.project) {
            throw new Error("No project open");
        }
        
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            throw new Error("Please select a composition");
        }
        
        if (comp.selectedLayers.length === 0) {
            throw new Error("Please select at least one layer");
        }
        
        // Your operations here
        
    } catch (e) {
        alert("Error occurred:\n" + e.toString() + 
              "\n\nLine: " + (e.line || "Unknown") +
              "\n\nPlease contact support if this continues.");
    } finally {
        app.endUndoGroup();
    }
})();
```

### Testing Checklist
Before deploying your script, test these scenarios:
- [ ] Test with no project open
- [ ] Test with no composition selected
- [ ] Test with no layers selected
- [ ] Test with locked layers
- [ ] Test with shy layers
- [ ] Test with 3D layers
- [ ] Test with nested compositions
- [ ] Test with missing footage
- [ ] Test undo/redo functionality
- [ ] Test with long operation (add progress bar)
- [ ] Test with non-English After Effects
- [ ] Test with different color bit depths (8/16/32)
- [ ] Test with audio layers
- [ ] Test with adjustment layers
- [ ] Test with shape layers
- [ ] Test with text layers
- [ ] Test with effects applied
- [ ] Test with expressions on properties
- [ ] Test with parented layers
- [ ] Test with guide layers

### Performance Best Practices
```javascript
// 1. Cache object references
// SLOW:
for (var i = 1; i <= 1000; i++) {
    app.project.activeItem.layer(1).property("Position").setValue([i, i]);
}

// FAST:
var comp = app.project.activeItem;
var layer = comp.layer(1);
var pos = layer.property("ADBE Transform Group").property("ADBE Position");
for (var i = 1; i <= 1000; i++) {
    pos.setValue([i, i]);
}

// 2. Suppress dialogs for batch operations
app.beginSuppressDialogs();
// ... batch operations
app.endSuppressDialogs(false);

// 3. Use matchNames instead of property names
// SLOWER:
var prop = layer.property("Transform").property("Position");
// FASTER:
var prop = layer.property("ADBE Transform Group").property("ADBE Position");

// 4. Minimize property lookups in loops
// SLOW:
for (var i = 1; i <= comp.numLayers; i++) {
    comp.layer(i).property("ADBE Transform Group").property("ADBE Opacity").setValue(50);
}

// FAST:
var TRANSFORM = "ADBE Transform Group";
var OPACITY = "ADBE Opacity";
for (var i = 1; i <= comp.numLayers; i++) {
    var layer = comp.layer(i);
    layer.property(TRANSFORM).property(OPACITY).setValue(50);
}
```

### Debugging Tips
```javascript
// 1. Console output (visible in ExtendScript Toolkit)
$.writeln("Debug info: " + variableName);

// 2. Check property existence
if (layer.property("ADBE Effect Parade").property("Gaussian Blur")) {
    $.writeln("Effect exists");
}

// 3. Log object properties
for (var prop in object) {
    $.writeln(prop + ": " + object[prop]);
}

// 4. Execution timing
var startTime = new Date().getTime();
// Your code here
var endTime = new Date().getTime();
$.writeln("Execution time: " + (endTime - startTime) + "ms");

// 5. Try-catch specific sections
try {
    riskyOperation();
} catch (e) {
    $.writeln("Error in riskyOperation: " + e.toString());
    $.writeln("Line: " + e.line);
}

// 6. Validate data types
$.writeln("Type of variable: " + typeof variableName);
$.writeln("Is Array: " + (variableName instanceof Array));

// 7. Property hierarchy inspection
function inspectProperty(prop, indent) {
    indent = indent || "";
    $.writeln(indent + prop.name + " (" + prop.matchName + ")");
    
    if (prop.numProperties) {
        for (var i = 1; i <= prop.numProperties; i++) {
            inspectProperty(prop.property(i), indent + "  ");
        }
    }
}

// Usage:
inspectProperty(layer.property("ADBE Transform Group"));
```

---

## Further Resources

### When to Consult Official Documentation
- **Complex property structures**: Check scripting guide for full property hierarchy
- **Effect-specific parameters**: Effect matchNames and parameters vary by version
- **New features**: After Effects updates add new scripting capabilities
- **Platform differences**: Mac vs Windows path handling, file system operations
- **Advanced features**: Camera options, 3D layer properties, motion graphics templates

### Official Adobe Resources
- Adobe After Effects Scripting Guide (PDF)
- ExtendScript Toolkit Guide (PDF)
- Adobe After Effects Scripting Forum
- Adobe Developer Documentation

### Script Development Workflow
1. **Plan**: Outline the script's functionality and user interface
2. **Prototype**: Create a basic version with core functionality
3. **Test**: Use the testing checklist to verify behavior
4. **Optimize**: Apply performance best practices
5. **Document**: Add comments and user instructions
6. **Deploy**: Package with README and installation instructions

### Recommended Tools
- **ExtendScript Toolkit**: Adobe's IDE for ExtendScript development
- **VS Code with ExtendScript debugger**: Modern alternative with better features
- **After Effects ScriptUI Panels**: Create dockable panel interfaces
- **Version Control**: Use Git to track script changes

### Best Practices Summary
1. Always use IIFE pattern for encapsulation
2. Include comprehensive error handling
3. Use matchNames for language independence
4. Cache property references in loops
5. Validate all inputs before processing
6. Provide progress feedback for long operations
7. Test thoroughly across different scenarios
8. Document your code clearly
9. Use descriptive variable names
10. Follow Adobe's coding conventions

### Community Resources
- After Effects Scripting Forum
- Creative COW After Effects forum
- aenhancers.com (community scripts and resources)
- Motion Script platform
- GitHub repositories with example scripts

---

## Script Template Library

### Minimal Script Template
```javascript
(function() {
    app.beginUndoGroup("Script Name");
    try {
        // Your code here
    } catch (e) {
        alert("Error: " + e.toString());
    } finally {
        app.endUndoGroup();
    }
})();
```

### Production-Ready Template
```javascript
(function() {
    // Script metadata
    var SCRIPT_NAME = "My Script";
    var SCRIPT_VERSION = "1.0.0";
    
    // Validate environment
    if (!(app instanceof Application)) {
        alert("This script requires After Effects");
        return;
    }
    
    if (!app.project) {
        alert("Please open a project first");
        return;
    }
    
    app.beginUndoGroup(SCRIPT_NAME);
    
    try {
        var comp = app.project.activeItem;
        
        if (!comp || !(comp instanceof CompItem)) {
            throw new Error("Please select a composition");
        }
        
        // Main script logic here
        main(comp);
        
    } catch (e) {
        alert(SCRIPT_NAME + " Error:\n" + e.toString() + 
              "\n\nLine: " + (e.line || "Unknown"));
    } finally {
        app.endUndoGroup();
    }
    
    function main(comp) {
        // Your main function logic
    }
})();
```

---

## Conclusion

This comprehensive guide covers everything you need to master After Effects scripting with ExtendScript. Remember:

- **Always validate inputs** before processing
- **Use matchNames** for reliable, language-independent scripts
- **Test thoroughly** across different scenarios
- **Optimize performance** for batch operations
- **Provide clear feedback** to users
- **Handle errors gracefully** with try-catch blocks

Keep this guide handy when developing scripts, and refer to Adobe's official documentation for the latest updates and advanced features.

**Version:** 2.0  
**Last Updated:** 2025  
**Compatibility:** After Effects CC 2015+

---
/**
 * AI API routes — Ollama + Gemini + OpenAI
 */

import { Router } from "express";
import OpenAI from "openai";
import {
  getOpenAIKey,
  getOpenAIModel,
  getGeminiApiKey,
  getAIStatus,
  getCodexCliModel,
  getCodexCliReasoning,
  getSettings,
} from "../lib/settings-store.js";
import { geminiComplete } from "../lib/gemini-client.js";
import { ollamaComplete } from "../lib/ollama-client.js";
import { claudeComplete } from "../lib/claude-client.js";
import { openRouterComplete } from "../lib/openrouter-client.js";
import { nimComplete } from "../lib/nim-client.js";
import { opencodeComplete } from "../lib/opencode-client.js";
import { compactAeContext } from "../lib/compact-context.js";
import { getSystemPrompt } from "../lib/ai-prompts.js";
import {
  getProviderChain,
  providerErrorMessage,
  isRetryableProviderError,
} from "../lib/resolve-provider.js";
import { transcribeVoiceAudio } from "../lib/voice-transcribe.js";
import { recordProviderError, recordUsage } from "../lib/usage-store.js";
import { runClaudeCliPrompt, runCodexCliPrompt } from "../lib/codex-cli.js";
import fs from "fs";
import path from "path";
import os from "os";

export const aiRouter = Router();

function getOpenAIClient() {
  const key = getOpenAIKey();
  if (!key) return null;
  return new OpenAI({ apiKey: key });
}

function buildCompletionPayload(text, provider, extra = {}) {
  const parsed = extractJsonBlock(text);
  let script = parsed?.script;
  if (!script && text) {
    const fenced = text.match(/```(?:jsx|javascript|extendscript)?\s*([\s\S]*?)```/i);
    const candidate = (fenced?.[1] || text).trim();
    if (
      !candidate.startsWith("{") &&
      (candidate.includes("app.") || candidate.includes("var ") || candidate.includes("function "))
    ) {
      script = candidate;
    }
  }

  return {
    text,
    provider,
    actions: parsed?.actions || extractActions(text),
    script: script,
    summary: parsed?.summary || parsed?.notes,
    suggestions: extractSuggestions(text),
    ...extra,
  };
}

function cleanCliError(error) {
  const text = String(error || "");
  if (/refresh token was already used|token_invalidated|401 Unauthorized|Please log out and sign in again/i.test(text)) {
    return "Codex login expired. Run `codex logout`, then `codex login`, then restart SCRIBE server and refresh Settings.";
  }
  if (/usage limit|Upgrade to Plus|try again at/i.test(text)) {
    const match = text.match(/You've hit your usage limit\.[^\r\n]+/i);
    return match ? match[0] : "Codex usage limit hit. Try again after your reset time or upgrade your account.";
  }
  const errors = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.startsWith("ERROR:"))
    .map((line) => line.replace(/^ERROR:\s*/, ""));
  return errors[errors.length - 1] || text;
}

async function runGemini(prompt, context, mode) {
  const result = await geminiComplete(prompt, context, mode);
  return buildCompletionPayload(result.text, "gemini", { model: result.model });
}

async function runOllama(prompt, context, mode) {
  const result = await ollamaComplete(prompt, context, mode);
  return buildCompletionPayload(result.text, "ollama", {
    model: result.model,
    slow: true,
  });
}

async function runClaude(prompt, context, mode) {
  const result = await claudeComplete(prompt, context, mode);
  return buildCompletionPayload(result.text, "claude", { model: result.model });
}

async function runClaudeCli(prompt, context, mode) {
  const compact = compactAeContext(context);
  const fullPrompt = [
    getSystemPrompt(mode),
    "",
    `Mode: ${mode}`,
    `AE Context: ${JSON.stringify(compact)}`,
    "",
    prompt,
  ].join("\n");
  const result = await runClaudeCliPrompt(fullPrompt, {
    timeoutMs: String(mode).startsWith("ai-script") ? 120000 : 60000,
  });
  if (!result.ok) throw new Error(result.error || "Claude CLI failed");
  recordUsage("claude-cli", "sonnet", { total_tokens: 0 });
  return buildCompletionPayload(result.output || "", "claude-cli", { model: "sonnet" });
}

async function runCodexCli(prompt, context, mode) {
  const compact = compactAeContext(context);
  const model = getCodexCliModel();
  const reasoning = getCodexCliReasoning();
  const system =
    mode === "ai-script" || mode === "ai-script-fix"
      ? `You write Adobe After Effects ExtendScript ES3 only.
Return ONLY JSON: {"script":"...","summary":"..."}.
Rules: var/function only; no const/let/arrows/import/require/File/Socket/system/BridgeTalk/executeCommand; no beginUndoGroup/endUndoGroup.
Start script with: var comp = app.project.activeItem; if (!(comp instanceof CompItem)) { throw new Error("Open a composition"); }
No hallucination: only create real AE layers/properties/keyframes. If context is missing, return a script that throws a clear error.
Pre-flight: Position/Anchor Point are arrays, Scale is an array, Rotation/Opacity are numbers. Expressions cannot access app.project. Check comp/layer/property/effect/group objects before use.
Avoid "Object is invalid": store layer/property refs immediately, never use refs after remove/precompose, check props before setValue, use matchName property groups when possible.
For animation: create text/shape/null/camera layers, set Position/Scale/Opacity/Rotation keyframes, use KeyframeEase safely after keys exist.
Keep scripts focused and under 220 lines unless user explicitly asks for huge scenes.`
      : getSystemPrompt(mode);
  const fullPrompt = [
    system,
    "",
    `Mode: ${mode}`,
    `AE Context: ${JSON.stringify(compact)}`,
    "",
    prompt,
  ].join("\n");
  const result = await runCodexCliPrompt(fullPrompt, {
    model,
    reasoning,
    timeoutMs: String(mode).startsWith("ai-script") ? 180000 : 90000,
  });
  if (!result.ok) throw new Error(cleanCliError(result.error) || "Codex CLI failed");
  recordUsage("codex-cli", model, { total_tokens: 0 });
  return buildCompletionPayload(result.output || "", "codex-cli", { model });
}

async function runOpenRouter(prompt, context, mode) {
  const result = await openRouterComplete(prompt, context, mode);
  return buildCompletionPayload(result.text, "openrouter", { model: result.model });
}

async function runNim(prompt, context, mode) {
  const result = await nimComplete(prompt, context, mode);
  return buildCompletionPayload(result.text, "nim", { model: result.model });
}

async function runOpencode(prompt, context, mode) {
  const result = await opencodeComplete(prompt, context, mode);
  return buildCompletionPayload(result.text, "opencode", { model: result.model });
}

async function runOpenAI(prompt, context, mode) {
  const client = getOpenAIClient();
  if (!client) {
    throw new Error("OpenAI API key not configured");
  }
  const compact = compactAeContext(context);
  const maxTokens = mode.startsWith("ai-script") ? 8192 : 4096;

  let userContent;
  const imageBase64 = context?.sandbox?.screenFrameBase64;
  if (imageBase64) {
    userContent = [
      {
        type: "text",
        text: `Mode: ${mode}\nContext: ${JSON.stringify(compact)}\nPrompt: ${prompt}`
      },
      {
        type: "image_url",
        image_url: {
          url: `data:image/jpeg;base64,${imageBase64}`
        }
      }
    ];
  } else {
    userContent = `Mode: ${mode}\nContext: ${JSON.stringify(compact)}\nPrompt: ${prompt}`;
  }

  const completion = await client.chat.completions.create({
    model: getOpenAIModel(),
    messages: [
      { role: "system", content: getSystemPrompt(mode) },
      {
        role: "user",
        content: userContent,
      },
    ],
    max_tokens: maxTokens,
    temperature: mode.startsWith("ai-script") ? 0.35 : 0.7,
  });
  const text = completion.choices[0]?.message?.content || "";
  recordUsage("openai", completion.model || getOpenAIModel(), completion.usage || {});
  return buildCompletionPayload(text, "openai");
}

async function runWithProvider(picked, prompt, context, mode, status) {
  if (picked === "ollama") return runOllama(prompt, context, mode);
  if (picked === "gemini") {
    if (!getGeminiApiKey()) throw new Error(providerErrorMessage("gemini", status));
    return runGemini(prompt, context, mode);
  }
  if (picked === "claude") return runClaude(prompt, context, mode);
  if (picked === "claude-cli") return runClaudeCli(prompt, context, mode);
  if (picked === "codex-cli") return runCodexCli(prompt, context, mode);
  if (picked === "openrouter") return runOpenRouter(prompt, context, mode);
  if (picked === "nim") return runNim(prompt, context, mode);
  if (picked === "opencode") return runOpencode(prompt, context, mode);
  if (picked === "openai") return runOpenAI(prompt, context, mode);
  throw new Error(`Unknown provider: ${picked}`);
}

aiRouter.post("/complete", async (req, res) => {
  const { prompt, context, mode = "command", provider = "auto" } = req.body || {};

  if (!prompt) {
    return res.status(400).json({ error: "prompt required" });
  }

  const status = getAIStatus();
  const chain = getProviderChain(provider, status, mode);

  if (!chain.length) {
    return res.status(400).json({
      error: providerErrorMessage(provider, status),
      provider: "none",
      geminiOAuth: status.geminiOAuth,
      geminiKey: status.geminiKey,
      ollama: status.ollama,
      ollamaEnabled: status.ollamaEnabled,
    });
  }

  const tried = [];
  let lastError = null;

  for (const picked of chain) {
    tried.push(picked);
    try {
      const isHeavy = String(mode).startsWith('ai-script') || String(mode).startsWith('engine-') || String(mode).startsWith('auto-edit');
      const providerTimeoutMs =
        picked === "codex-cli" || picked === "claude-cli"
          ? isHeavy
            ? 240000
            : 180000
          : isHeavy
            ? 120000
            : 45000;
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`${picked} timed out after ${providerTimeoutMs / 1000}s`)), providerTimeoutMs)
      );
      const payload = await Promise.race([
        runWithProvider(picked, prompt, context, mode, status),
        timeoutPromise,
      ]);
      if (String(mode).startsWith("ai-script") && !payload.script && !payload.text) {
        throw new Error("AI returned empty script");
      }
      if (String(mode).startsWith("ai-script") && !payload.script) {
        const hasJson = /"script"\s*:/i.test(payload.text || "");
        if (!hasJson) throw new Error("AI did not return runnable ExtendScript");
      }
      return res.json({
        ...payload,
        providerUsed: picked,
        triedProviders: tried,
        notice:
          tried.length > 1
            ? `Used ${picked} after trying: ${tried.slice(0, -1).join(", ")}`
            : undefined,
      });
    } catch (e) {
      lastError = e;
      recordProviderError(picked, e);
      const msg = e?.message || String(e);
      if (!isRetryableProviderError(msg) && chain.length === 1) break;
      if (picked === chain[chain.length - 1]) break;
    }
  }

  const msg = lastError?.message || String(lastError) || "All AI providers failed";
  if (/Gemini API key required/i.test(msg)) {
    return res.status(400).json({
      error: providerErrorMessage("gemini", status),
      provider: "gemini",
      triedProviders: tried,
    });
  }
  if (lastError?.quota) {
    return res.status(429).json({
      error: msg,
      provider: tried[tried.length - 1] || "none",
      quotaExceeded: true,
      triedProviders: tried,
    });
  }
  return res.status(500).json({
    error: msg,
    triedProviders: tried,
    hint:
      chain.length > 1
        ? `Tried: ${tried.join(" → ")}. Connect OpenRouter or NVIDIA NIM in Settings.`
        : providerErrorMessage(provider, status),
  });
});

/** Voice STT — Gemini (free key) or OpenAI Whisper when Google speech blocked in CEP */
aiRouter.post("/voice/transcribe", async (req, res) => {
  const { audio, mimeType = "audio/webm" } = req.body || {};
  if (!audio) return res.status(400).json({ error: "audio required", text: "" });

  const result = await transcribeVoiceAudio(audio, mimeType);
  if (!result.text) {
    return res.status(result.error ? 400 : 500).json(result);
  }
  res.json(result);
});

aiRouter.post("/transcribe", async (req, res) => {
  const { audio, mimeType = "audio/webm" } = req.body || {};
  if (!audio) return res.status(400).json({ error: "audio required" });

  const result = await transcribeVoiceAudio(audio, mimeType);
  if (!result.text) {
    return res.status(400).json(result);
  }
  res.json({ text: result.text, engine: result.engine, words: [], segments: [] });
});

function extractJsonBlock(text) {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const blocks = [fenced?.[1], text].filter(Boolean);
  for (const block of blocks) {
    try {
      return JSON.parse(block.trim());
    } catch {
      /* continue */
    }
  }
  return null;
}



function extractActions(text) {
  const parsed = extractJsonBlock(text);
  if (Array.isArray(parsed?.actions) && parsed.actions.length) {
    return parsed.actions;
  }
  return undefined;
}

function extractSuggestions(text) {
  const lines = text.split("\n").filter((l) => l.trim().startsWith("-"));
  if (lines.length) {
    return lines.map((l) => l.replace(/^-\s*/, "").trim()).slice(0, 4);
  }
  return [
    "Add subtle camera shake",
    "Create smooth cinematic zoom",
    "Apply premium color grade",
  ];
}

async function uploadToTmpFiles(filePath) {
  const fileBuffer = fs.readFileSync(filePath);
  const fileName = path.basename(filePath);
  const boundary = "----ScribeTmpFilesBoundary" + Date.now();
  const bodyParts = [
    `--${boundary}\r\n`,
    `Content-Disposition: form-data; name="file"; filename="${fileName}"\r\n`,
    `Content-Type: application/octet-stream\r\n\r\n`,
  ];

  const header = Buffer.from(bodyParts.join(""));
  const footer = Buffer.from(`\r\n--${boundary}--\r\n`);
  const body = Buffer.concat([header, fileBuffer, footer]);

  const resp = await fetch("https://tmpfiles.org/api/v1/upload", {
    method: "POST",
    headers: {
      "Content-Type": `multipart/form-data; boundary=${boundary}`,
    },
    body: body,
  });

  if (!resp.ok) {
    throw new Error(`Failed to upload to tmpfiles.org: ${resp.statusText}`);
  }

  const resJson = await resp.json();
  if (resJson.status === "success" && resJson.data?.url) {
    return resJson.data.url.replace("tmpfiles.org/", "tmpfiles.org/dl/");
  } else {
    throw new Error("Invalid response from tmpfiles.org");
  }
}

async function downloadResult(url) {
  const fileResp = await fetch(url);
  if (!fileResp.ok) {
    throw new Error(`Failed to download result video: ${fileResp.statusText}`);
  }
  const arrayBuffer = await fileResp.arrayBuffer();
  const downloadDir = path.join(os.tmpdir(), `scribe-download-${Date.now()}`);
  fs.mkdirSync(downloadDir, { recursive: true });
  const finalPath = path.join(downloadDir, "edited_video.mp4");
  fs.writeFileSync(finalPath, Buffer.from(arrayBuffer));
  return finalPath;
}

aiRouter.post("/modelslab/video-edit", async (req, res) => {
  try {
    const { videoPath, prompt } = req.body || {};
    if (!videoPath || !prompt) {
      return res.status(400).json({ ok: false, error: "videoPath and prompt required" });
    }

    const s = getSettings();
    const modelslabApiKey = s.modelslabApiKey;
    if (!modelslabApiKey) {
      return res.status(400).json({ ok: false, error: "ModelsLab API key is not configured. Go to Settings." });
    }

    if (!fs.existsSync(videoPath)) {
      return res.status(400).json({ ok: false, error: `Local video file not found at: ${videoPath}` });
    }

    const publicUrl = await uploadToTmpFiles(videoPath);
    console.log(`[ModelsLab] Uploaded source video to: ${publicUrl}`);

    const createResp = await fetch("https://modelslab.com/api/v6/video/img2video", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        key: modelslabApiKey,
        model_id: "happyhorse-1.0-v2v",
        video_url: publicUrl,
        prompt: prompt,
        width: 1024,
        height: 1024,
        temp: true,
      }),
    });

    if (!createResp.ok) {
      throw new Error(`ModelsLab job creation failed: ${createResp.statusText}`);
    }

    const createJson = await createResp.json();
    if (createJson.status === "error" || createJson.status === "failed") {
      throw new Error(createJson.message || "ModelsLab failed to start job");
    }

    const jobId = createJson.id || createJson.request_id;
    if (!jobId) {
      if (createJson.output && createJson.output[0]) {
        const downloadPath = await downloadResult(createJson.output[0]);
        return res.json({ ok: true, path: downloadPath });
      }
      throw new Error("No job ID or output returned from ModelsLab");
    }

    let videoUrl = null;
    let attempts = 0;
    const maxAttempts = 60;

    console.log(`[ModelsLab] Started HappyHorse job ${jobId}. Polling...`);

    while (attempts < maxAttempts) {
      await new Promise((resolve) => setTimeout(resolve, 10000));
      const pollResp = await fetch(`https://modelslab.com/api/v6/video/fetch/${jobId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: modelslabApiKey }),
      });

      if (!pollResp.ok) {
        throw new Error(`Polling failed: ${pollResp.statusText}`);
      }

      const pollJson = await pollResp.json();
      if (pollJson.status === "success" && pollJson.output && pollJson.output.length > 0) {
        videoUrl = pollJson.output[0];
        break;
      }
      if (pollJson.status === "failed" || pollJson.status === "error") {
        throw new Error(pollJson.message || "ModelsLab video generation failed.");
      }
      attempts++;
    }

    if (!videoUrl) {
      throw new Error("Job timed out without generating video.");
    }

    console.log(`[ModelsLab] Video ready! Downloading from: ${videoUrl}`);
    const downloadPath = await downloadResult(videoUrl);

    res.json({ ok: true, path: downloadPath });
  } catch (e) {
    console.error("[ModelsLab Error]", e);
    res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

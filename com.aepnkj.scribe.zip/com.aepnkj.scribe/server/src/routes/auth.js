/**
 * Google OAuth for Gemini + auth routes
 */
import { Router } from "express";
import { createHash, randomBytes } from "crypto";
import {
  setGoogleTokens,
  clearGoogleAuth,
  getAIStatus,
  setBrokerTokens,
  clearBrokerTokens,
} from "../lib/settings-store.js";

export const authRouter = Router();

// Standard Google sign-in scopes only. The generative-language scope is not
// available for third-party OAuth web clients (invalid_scope). Use GEMINI_API_KEY
// or paste a key in SCRIBE Settings for Gemini API calls.
const SCOPES = ["openid", "email", "profile"].join(" ");

const pendingStates = new Map();
const pendingBrokerStates = new Map();

function base64Url(buffer) {
  return Buffer.from(buffer)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function brokerConfig(provider) {
  const key = String(provider || "").toUpperCase().replace(/[^A-Z0-9]/g, "_");
  return {
    provider: String(provider || "").toLowerCase(),
    clientId: process.env[`SCRIBE_BROKER_${key}_CLIENT_ID`],
    clientSecret: process.env[`SCRIBE_BROKER_${key}_CLIENT_SECRET`] || "",
    authUrl: process.env[`SCRIBE_BROKER_${key}_AUTH_URL`],
    tokenUrl: process.env[`SCRIBE_BROKER_${key}_TOKEN_URL`],
    userInfoUrl: process.env[`SCRIBE_BROKER_${key}_USERINFO_URL`] || "",
    scopes: process.env[`SCRIBE_BROKER_${key}_SCOPES`] || "openid profile email offline_access",
  };
}

function getRedirectUri(req) {
  const base = process.env.OAUTH_REDIRECT_BASE || `http://127.0.0.1:${process.env.PORT || 3742}`;
  return `${base}/api/auth/google/callback`;
}

function getBrokerRedirectUri(req, provider) {
  const base = process.env.OAUTH_REDIRECT_BASE || `http://127.0.0.1:${process.env.PORT || 3742}`;
  return `${base}/api/auth/broker/${encodeURIComponent(provider)}/callback`;
}

authRouter.get("/status", (_req, res) => {
  res.json(getAIStatus());
});

authRouter.get("/google", (req, res) => {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  if (!clientId) {
    return res.status(400).send(errorPage("Google OAuth not configured", "Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to server/.env"));
  }

  const state = randomBytes(16).toString("hex");
  pendingStates.set(state, Date.now());

  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: getRedirectUri(req),
    response_type: "code",
    scope: SCOPES,
    state,
    access_type: "offline",
    prompt: "consent",
  });

  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
});

authRouter.get("/google/callback", async (req, res) => {
  const { code, state, error } = req.query;

  if (error) {
    return res.send(errorPage("Sign-in cancelled", String(error)));
  }

  if (!code || !state || !pendingStates.has(String(state))) {
    return res.status(400).send(errorPage("Invalid OAuth state", "Try signing in again from SCRIBE Settings."));
  }
  pendingStates.delete(String(state));

  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code: String(code),
        client_id: process.env.GOOGLE_CLIENT_ID,
        client_secret: process.env.GOOGLE_CLIENT_SECRET,
        redirect_uri: getRedirectUri(req),
        grant_type: "authorization_code",
      }),
    });

    if (!tokenRes.ok) {
      const err = await tokenRes.text();
      return res.send(errorPage("Token exchange failed", err));
    }

    const tokens = await tokenRes.json();
    tokens.expires_at = Date.now() + (tokens.expires_in || 3600) * 1000;

    let user = { email: "Google account", name: "Gemini User" };
    try {
      const userRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: `Bearer ${tokens.access_token}` },
      });
      if (userRes.ok) user = await userRes.json();
    } catch {
      /* optional */
    }

    setGoogleTokens(tokens, { email: user.email, name: user.name });

    res.send(successPage(user.email || user.name));
  } catch (e) {
    res.send(errorPage("OAuth error", e.message));
  }
});

authRouter.post("/google/logout", (_req, res) => {
  clearGoogleAuth();
  res.json({ ok: true });
});

authRouter.get("/broker/:provider/start", (req, res) => {
  const cfg = brokerConfig(req.params.provider);
  if (!cfg.clientId || !cfg.authUrl || !cfg.tokenUrl) {
    return res.status(400).send(errorPage(
      "Broker OAuth not configured",
      `Add SCRIBE_BROKER_${String(req.params.provider).toUpperCase()}_CLIENT_ID, AUTH_URL, and TOKEN_URL to server/.env`
    ));
  }

  const state = randomBytes(18).toString("hex");
  const codeVerifier = base64Url(randomBytes(48));
  const codeChallenge = base64Url(createHash("sha256").update(codeVerifier).digest());
  pendingBrokerStates.set(state, {
    provider: cfg.provider,
    codeVerifier,
    createdAt: Date.now(),
  });

  const params = new URLSearchParams({
    client_id: cfg.clientId,
    redirect_uri: getBrokerRedirectUri(req, cfg.provider),
    response_type: "code",
    scope: cfg.scopes,
    state,
    code_challenge: codeChallenge,
    code_challenge_method: "S256",
  });

  res.redirect(`${cfg.authUrl}${cfg.authUrl.includes("?") ? "&" : "?"}${params}`);
});

authRouter.get("/broker/:provider/callback", async (req, res) => {
  const { code, state, error } = req.query;
  const provider = String(req.params.provider || "").toLowerCase();
  if (error) return res.send(errorPage("Sign-in cancelled", String(error)));
  const pending = pendingBrokerStates.get(String(state || ""));
  if (!code || !pending || pending.provider !== provider) {
    return res.status(400).send(errorPage("Invalid broker state", "Try signing in again from SCRIBE Settings."));
  }
  pendingBrokerStates.delete(String(state));

  const cfg = brokerConfig(provider);
  try {
    const body = new URLSearchParams({
      grant_type: "authorization_code",
      code: String(code),
      client_id: cfg.clientId,
      redirect_uri: getBrokerRedirectUri(req, provider),
      code_verifier: pending.codeVerifier,
    });
    if (cfg.clientSecret) body.set("client_secret", cfg.clientSecret);

    const tokenRes = await fetch(cfg.tokenUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    const tokenText = await tokenRes.text();
    if (!tokenRes.ok) return res.send(errorPage("Broker token exchange failed", tokenText));
    const tokens = JSON.parse(tokenText);
    if (tokens.expires_in) tokens.expires_at = Date.now() + Number(tokens.expires_in) * 1000;

    let user = null;
    if (cfg.userInfoUrl && tokens.access_token) {
      try {
        const userRes = await fetch(cfg.userInfoUrl, {
          headers: { Authorization: `Bearer ${tokens.access_token}` },
        });
        if (userRes.ok) user = await userRes.json();
      } catch {
        /* optional */
      }
    }

    setBrokerTokens(provider, tokens, user);
    res.send(successPage(`${provider} broker account`));
  } catch (e) {
    res.send(errorPage("Broker OAuth error", e.message || String(e)));
  }
});

authRouter.post("/broker/:provider/logout", (req, res) => {
  clearBrokerTokens(String(req.params.provider || "").toLowerCase());
  res.json({ ok: true, ...getAIStatus() });
});

function successPage(email) {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>SCRIBE — Connected</title>
<style>body{font-family:system-ui;background:#050508;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
.card{background:#12121c;border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:2rem;max-width:400px;text-align:center}
h1{color:#818cf8;font-size:1.25rem}p{color:rgba(255,255,255,.6);margin:1rem 0;line-height:1.5}.ok{color:#34d399}</style></head>
<body><div class="card"><h1>Google account linked</h1><p class="ok">✓ Signed in as ${escapeHtml(email)}</p>
<p>Add your Gemini API key in SCRIBE Settings (aistudio.google.com/apikey), then close this window.</p></div></body></html>`;
}

function errorPage(title, detail) {
  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>SCRIBE — Error</title>
<style>body{font-family:system-ui;background:#050508;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
.card{background:#12121c;border:1px solid rgba(248,113,113,.3);border-radius:16px;padding:2rem;max-width:440px}
h1{color:#f87171;font-size:1.25rem}p{color:rgba(255,255,255,.6);margin:.75rem 0;font-size:.9rem}pre{font-size:.75rem;overflow:auto;color:#f87171}</style></head>
<body><div class="card"><h1>${escapeHtml(title)}</h1><p>${escapeHtml(detail)}</p>
<p>Return to SCRIBE Settings and try again.</p></div></body></html>`;
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Clean stale OAuth states every 10 min
setInterval(() => {
  const cutoff = Date.now() - 10 * 60 * 1000;
  for (const [k, t] of pendingStates) {
    if (t < cutoff) pendingStates.delete(k);
  }
  for (const [k, v] of pendingBrokerStates) {
    if (v.createdAt < cutoff) pendingBrokerStates.delete(k);
  }
}, 600_000);

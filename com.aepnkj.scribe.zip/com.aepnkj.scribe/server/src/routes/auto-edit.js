import { Router } from "express";
import { writeFileSync, mkdirSync } from "fs";
import { join, extname } from "path";
import { tmpdir } from "os";
import { analyzeAutoEdit, buildAutoEdit } from "../lib/auto-edit-analyze.js";
import { deepAnalyzeAutoEdit, getMediaPipelineStatus } from "../lib/auto-edit-deep.js";
import { transcribeCaptionsFromAudio } from "../lib/captions-transcribe.js";

export const autoEditRouter = Router();

autoEditRouter.post("/upload-media", (req, res) => {
  try {
    const { data, mimeType = "application/octet-stream", name = "upload" } = req.body || {};
    if (!data) return res.status(400).json({ ok: false, error: "data required" });
    const ext = extname(name) || (mimeType.includes("video") ? ".mp4" : ".mp3");
    const dir = join(tmpdir(), `scribe-upload-${Date.now()}`);
    mkdirSync(dir, { recursive: true });
    const filePath = join(dir, `file${ext}`);
    writeFileSync(filePath, Buffer.from(data, "base64"));
    res.json({ ok: true, path: filePath, mimeType, name });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

autoEditRouter.post("/captions/transcribe", async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body || {};
    const result = await transcribeCaptionsFromAudio(audioBase64, mimeType);
    res.json(result);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message || String(e), words: [] });
  }
});

autoEditRouter.get("/media-status", async (_req, res) => {
  const ffmpeg = await getMediaPipelineStatus();
  res.json({ ok: true, ffmpeg });
});

autoEditRouter.post("/analyze-deep", async (req, res) => {
  try {
    const result = await deepAnalyzeAutoEdit(req.body);
    res.json(result);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

autoEditRouter.post("/analyze", async (req, res) => {
  try {
    const result = await analyzeAutoEdit(req.body);
    res.json(result);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

autoEditRouter.post("/build", async (req, res) => {
  try {
    const result = await buildAutoEdit(req.body);
    res.json(result);
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message || String(e) });
  }
});

/**
 * Sandbox assets — PNG frame sequences for AE import
 */
import { Router } from "express";
import { mkdirSync, writeFileSync, existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { randomUUID } from "crypto";
import os from "os";

const __dirname = dirname(fileURLToPath(import.meta.url));
const FRAMES_ROOT = join(__dirname, "../../data/frames");

function ensureFramesDir() {
  if (!existsSync(FRAMES_ROOT)) mkdirSync(FRAMES_ROOT, { recursive: true });
}

export const sandboxRouter = Router();

sandboxRouter.get("/live-frame", (req, res) => {
  const framePath = join(os.tmpdir(), "scribe_live_frame.png");
  if (existsSync(framePath)) {
    res.sendFile(framePath);
  } else {
    // 1x1 transparent PNG fallback
    const fallback = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", "base64");
    res.writeHead(200, {
      "Content-Type": "image/png",
      "Content-Length": fallback.length,
    });
    res.end(fallback);
  }
});

sandboxRouter.post("/save-frames", (req, res) => {
  const { frames } = req.body || {};
  if (!Array.isArray(frames) || frames.length < 1) {
    return res.status(400).json({ error: "frames array required (base64 PNG)" });
  }
  if (frames.length > 300) {
    return res.status(400).json({ error: "Max 300 frames per export" });
  }

  try {
    ensureFramesDir();
    const id = randomUUID().slice(0, 8);
    const dir = join(FRAMES_ROOT, id);
    mkdirSync(dir, { recursive: true });

    for (let i = 0; i < frames.length; i++) {
      const raw = String(frames[i]).replace(/^data:image\/\w+;base64,/, "");
      const buf = Buffer.from(raw, "base64");
      const num = String(i + 1).padStart(4, "0");
      writeFileSync(join(dir, `frame_${num}.png`), buf);
    }

    const folderPath = dir.replace(/\\/g, "/");
    res.json({ ok: true, folderPath, frameCount: frames.length, id });
  } catch (e) {
    res.status(500).json({ error: e.message || "Failed to save frames" });
  }
});

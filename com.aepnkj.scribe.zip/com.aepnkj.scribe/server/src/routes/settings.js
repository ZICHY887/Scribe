/**
 * Settings API — save API keys from SCRIBE panel
 */
import { Router } from "express";
import { resetUsage } from "../lib/usage-store.js";
import {
  setOpenAIKey,
  setOpenAIModel,
  setGeminiApiKey,
  setGeminiModel,
  setOllamaModel,
  setOllamaBaseUrl,
  setClaudeApiKey,
  setClaudeModel,
  setOpenRouterApiKey,
  setOpenRouterModel,
  setNimApiKey,
  setNimModel,
  setNimBaseUrl,
  setOpencodeApiKey,
  setOpencodeModel,
  setOpencodeBaseUrl,
  setCodexCliConfig,
  setProvidersEnabled,
  setOllamaEnabled,
  getAIStatus,
  getSettings,
  getOllamaBaseUrl,
  getProvidersEnabled,
  setModelsLabApiKey,
} from "../lib/settings-store.js";
import {
  listOllamaModels,
  pickDefaultOllamaModel,
  ollamaReachable,
} from "../lib/ollama-client.js";
import { testNimConnection, testOpencodeConnection, testOpenRouterConnection, testAllProviders } from "../lib/provider-test.js";
import { getClaudeCliStatus, getCodexCliStatus, installCli, openSystemBrowser, startClaudeCliLogin, startCodexCliLogin } from "../lib/codex-cli.js";

export const settingsRouter = Router();

settingsRouter.get("/ai-status", (_req, res) => {
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.get("/keys", (_req, res) => {
  const s = getSettings();
  res.json({
    hasOpenAI: !!s.openaiApiKey,
    hasGeminiKey: !!s.geminiApiKey,
    openaiPreview: maskKey(s.openaiApiKey),
    geminiPreview: maskKey(s.geminiApiKey),
    ollamaModel: s.ollamaModel || "",
  });
});

settingsRouter.post("/openai-key", (req, res) => {
  const { key, model } = req.body || {};
  if (key !== undefined) setOpenAIKey(key || "");
  if (model) setOpenAIModel(model);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/gemini-key", (req, res) => {
  const { key, model } = req.body || {};
  if (key !== undefined) setGeminiApiKey(key || "");
  if (model) setGeminiModel(model);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/modelslab-key", (req, res) => {
  const { key } = req.body || {};
  if (key !== undefined) setModelsLabApiKey(key || "");
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/ollama-model", (req, res) => {
  const { model } = req.body || {};
  setOllamaModel(model || "");
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/ollama-base-url", (req, res) => {
  const { url } = req.body || {};
  if (url) setOllamaBaseUrl(url);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/claude-key", (req, res) => {
  const { key, model } = req.body || {};
  setClaudeApiKey(key || "");
  if (model) setClaudeModel(model);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/ollama-enabled", (req, res) => {
  const { enabled } = req.body || {};
  setOllamaEnabled(!!enabled);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/openrouter-key", (req, res) => {
  const { key, model } = req.body || {};
  if (key !== undefined) setOpenRouterApiKey(key);
  if (model) setOpenRouterModel(model);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/nim-key", (req, res) => {
  const { key, model, baseUrl } = req.body || {};
  if (key !== undefined) setNimApiKey(key);
  if (model) setNimModel(model);
  if (baseUrl) setNimBaseUrl(baseUrl);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/opencode", (req, res) => {
  const { key, model, baseUrl } = req.body || {};
  if (key !== undefined) setOpencodeApiKey(key || "");
  if (model) setOpencodeModel(model);
  if (baseUrl !== undefined) setOpencodeBaseUrl(baseUrl || "");
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.post("/codex-cli", (req, res) => {
  const { model, reasoning } = req.body || {};
  setCodexCliConfig(model, reasoning);
  res.json({ ok: true, ...getAIStatus() });
});

settingsRouter.get("/codex-cli/status", async (_req, res) => {
  res.json({ ok: true, ...(await getCodexCliStatus()), ...getAIStatus() });
});

settingsRouter.post("/codex-cli/login", async (_req, res) => {
  const login = await startCodexCliLogin();
  res.json({ ok: login.ok, ...login, ...(await getCodexCliStatus()), ...getAIStatus() });
});

settingsRouter.post("/codex-cli/install", async (_req, res) => {
  const install = await installCli("codex");
  res.json({ ok: install.ok, ...install, ...(await getCodexCliStatus()), ...getAIStatus() });
});

settingsRouter.get("/claude-cli/status", async (_req, res) => {
  res.json({ ok: true, ...(await getClaudeCliStatus()), ...getAIStatus() });
});

settingsRouter.post("/claude-cli/login", async (_req, res) => {
  const login = await startClaudeCliLogin();
  res.json({ ok: login.ok, ...login, ...(await getClaudeCliStatus()), ...getAIStatus() });
});

settingsRouter.post("/claude-cli/install", async (_req, res) => {
  const install = await installCli("claude");
  res.json({ ok: install.ok, ...install, ...(await getClaudeCliStatus()), ...getAIStatus() });
});

settingsRouter.post("/open-login-url", async (req, res) => {
  const { provider } = req.body || {};
  const urls = {
    codex: "https://chatgpt.com/auth/login",
    openai: "https://platform.openai.com/api-keys",
    claude: "https://claude.ai/login",
    gemini: "https://aistudio.google.com/apikey",
    openrouter: "https://openrouter.ai/keys",
  };
  const url = urls[provider];
  if (!url) return res.status(400).json({ ok: false, error: "Unknown login provider" });
  const opened = await openSystemBrowser(url);
  res.json({ ...opened, provider, url });
});

settingsRouter.post("/providers-enabled", (req, res) => {
  const { providers } = req.body || {};
  setProvidersEnabled(providers || {});
  res.json({ ok: true, ...getAIStatus() });
});

/** One-click local NIM (Docker) — placeholder key + localhost URL */
settingsRouter.post("/nim-local-preset", (req, res) => {
  const { baseUrl } = req.body || {};
  setNimApiKey("local-nim");
  setNimModel("meta/llama-3.1-8b-instruct");
  setNimBaseUrl(baseUrl || "http://127.0.0.1:8000/v1");
  const pe = { ...getProvidersEnabled(), nim: true };
  setProvidersEnabled(pe);
  res.json({ ok: true, ...getAIStatus(), message: "Local NIM preset saved" });
});

/** One-click OpenCode local preset */
settingsRouter.post("/opencode-local-preset", (req, res) => {
  const { baseUrl } = req.body || {};
  setOpencodeApiKey("opencode-local");
  setOpencodeModel("default");
  setOpencodeBaseUrl(baseUrl || "http://127.0.0.1:4096/v1");
  const pe = { ...getProvidersEnabled(), opencode: true };
  setProvidersEnabled(pe);
  res.json({ ok: true, ...getAIStatus(), message: "OpenCode local preset saved" });
});

settingsRouter.get("/test-nim", async (_req, res) => {
  res.json(await testNimConnection());
});

settingsRouter.get("/test-opencode", async (_req, res) => {
  res.json(await testOpencodeConnection());
});

settingsRouter.get("/test-openrouter", async (_req, res) => {
  res.json(await testOpenRouterConnection());
});

settingsRouter.get("/test-all", async (_req, res) => {
  res.json(await testAllProviders());
});

/** Scan Ollama on this PC (127.0.0.1:11434) */
settingsRouter.get("/ollama/models", async (req, res) => {
  const baseUrl = req.query.baseUrl || getOllamaBaseUrl();
  try {
    const models = await listOllamaModels(baseUrl);
    const suggested = pickDefaultOllamaModel(models);
    const current = getSettings().ollamaModel;
    res.json({
      ok: true,
      baseUrl,
      models,
      suggested,
      current,
      reachable: true,
    });
  } catch (e) {
    res.json({
      ok: false,
      baseUrl,
      models: [],
      error: e.message || "Ollama not running",
      reachable: false,
      hint: "Run: ollama serve — then: ollama pull qwen2.5-coder:14b",
    });
  }
});

settingsRouter.get("/ollama/ping", async (_req, res) => {
  const ok = await ollamaReachable();
  res.json({ ok, ...getAIStatus() });
});

/** Reset all usage/quota counters (user-triggered) */
settingsRouter.post("/reset-usage", (_req, res) => {
  resetUsage();
  res.json({ ok: true, message: "Usage counters reset", ...getAIStatus() });
});

function maskKey(key) {
  if (!key || key.length < 8) return key ? "••••••••" : "";
  return key.slice(0, 4) + "••••" + key.slice(-4);
}

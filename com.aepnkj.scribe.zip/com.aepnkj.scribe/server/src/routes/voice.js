/**
 * SCRIBE Voice transcription route
 * POST /api/voice/transcribe
 * Accepts base64 audio, transcribes via Gemini (free) or OpenAI Whisper
 */
import { Router } from "express";
import { getGeminiApiKey, getOpenAIKey, getOpenRouterApiKey } from "../lib/settings-store.js";

export const voiceRouter = Router();

voiceRouter.post("/transcribe", async (req, res) => {
  try {
    const { audio, mimeType = "audio/webm" } = req.body || {};
    if (!audio) {
      return res.json({ error: "No audio data provided" });
    }

    // Try Gemini first (free, no quota issues for short audio)
    const geminiKey = getGeminiApiKey();
    if (geminiKey) {
      try {
        const result = await transcribeWithGemini(audio, mimeType, geminiKey);
        if (result) {
          return res.json({ text: result, engine: "gemini" });
        }
      } catch (e) {
        console.warn("Gemini voice failed, trying OpenAI:", e.message);
      }
    }

    // Try OpenAI Whisper
    const openaiKey = getOpenAIKey();
    if (openaiKey) {
      try {
        const result = await transcribeWithWhisper(audio, mimeType, openaiKey);
        if (result) {
          return res.json({ text: result, engine: "whisper" });
        }
      } catch (e) {
        console.warn("Whisper failed:", e.message);
      }
    }

    // Try OpenRouter (some models support audio)
    const orKey = getOpenRouterApiKey();
    if (orKey) {
      try {
        const result = await transcribeWithOpenRouter(audio, mimeType, orKey);
        if (result) {
          return res.json({ text: result, engine: "openrouter" });
        }
      } catch (e) {
        console.warn("OpenRouter voice failed:", e.message);
      }
    }

    return res.json({
      error: "No transcription provider available. Add a Gemini API key (free) or OpenAI key in Settings.",
    });
  } catch (e) {
    console.error("Voice transcribe error:", e);
    return res.status(500).json({ error: e.message || "Transcription failed" });
  }
});

async function transcribeWithGemini(audioBase64, mimeType, apiKey) {
  const models = [
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite",
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-flash",
  ];
  let lastError = null;

  for (const model of models) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
      const body = {
        contents: [
          {
            parts: [
              {
                inlineData: {
                  mimeType: mimeType || "audio/webm",
                  data: audioBase64,
                },
              },
              {
                text: "Transcribe this audio exactly. Return ONLY the spoken text, nothing else. If silence or unclear, return empty string.",
              },
            ],
          },
        ],
        generationConfig: {
          maxOutputTokens: 256,
          temperature: 0.1,
        },
      };

      const resp = await fetch(`${url}?key=${apiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(15000),
      });

      if (!resp.ok) {
        throw new Error(`Gemini ${resp.status} with model ${model}: ${await resp.text()}`);
      }

      const data = await resp.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "";
      return text;
    } catch (e) {
      lastError = e;
      console.warn(`Gemini voice transcription failed with model ${model}:`, e.message);
      continue;
    }
  }

  throw lastError || new Error("All Gemini models failed");
}

async function transcribeWithWhisper(audioBase64, mimeType, apiKey) {
  // Convert base64 to a Blob-like buffer
  const buffer = Buffer.from(audioBase64, "base64");
  const ext = mimeType.includes("ogg") ? "ogg" : mimeType.includes("mp4") ? "mp4" : "webm";

  // Use FormData with the Whisper API
  const boundary = "----ScribeVoiceBoundary" + Date.now();
  const bodyParts = [
    `--${boundary}\r\n`,
    `Content-Disposition: form-data; name="file"; filename="voice.${ext}"\r\n`,
    `Content-Type: ${mimeType}\r\n\r\n`,
  ];

  const header = Buffer.from(bodyParts.join(""));
  const footer = Buffer.from(`\r\n--${boundary}\r\nContent-Disposition: form-data; name="model"\r\n\r\nwhisper-1\r\n--${boundary}--\r\n`);
  const body = Buffer.concat([header, buffer, footer]);

  const resp = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": `multipart/form-data; boundary=${boundary}`,
    },
    body,
    signal: AbortSignal.timeout(20000),
  });

  if (!resp.ok) {
    throw new Error(`Whisper ${resp.status}: ${await resp.text()}`);
  }

  const data = await resp.json();
  return data?.text?.trim() || "";
}

async function transcribeWithOpenRouter(audioBase64, mimeType, apiKey) {
  // Use Gemini via OpenRouter for audio transcription
  const resp = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://scribe-by-aepnkj.local",
    },
    body: JSON.stringify({
      model: "google/gemini-2.0-flash:free",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Transcribe this audio exactly. Return ONLY the spoken text, nothing else.",
            },
            {
              type: "image_url",
              image_url: {
                url: `data:${mimeType};base64,${audioBase64}`,
              },
            },
          ],
        },
      ],
      max_tokens: 256,
      temperature: 0.1,
    }),
    signal: AbortSignal.timeout(15000),
  });

  if (!resp.ok) {
    throw new Error(`OpenRouter voice ${resp.status}`);
  }

  const data = await resp.json();
  return data?.choices?.[0]?.message?.content?.trim() || "";
}

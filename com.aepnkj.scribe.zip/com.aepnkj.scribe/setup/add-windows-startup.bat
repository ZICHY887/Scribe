@echo off
cd /d "%~dp0.."
set "ROOT=%CD%"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "VBS=%STARTUP%\SCRIBE-Server.vbs"
set "LAUNCHER=%ROOT%\setup\launch-server-hidden.vbs"

(
echo Set sh = CreateObject^("WScript.Shell"^)
echo sh.CurrentDirectory = "%ROOT%"
echo sh.Run """"%LAUNCHER%"""", 0, False
) > "%VBS%"

echo SCRIBE server will start hidden when Windows boots.
echo Startup: %VBS%
echo To remove: run remove-windows-startup.bat
pause

Set sh = CreateObject("WScript.Shell")
root = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
If Right(root, 6) = "setup" Then root = CreateObject("Scripting.FileSystemObject").GetParentFolderName(root)
sh.CurrentDirectory = root
sh.Run "cmd /c """ & root & "\start-server.bat""", 0, False

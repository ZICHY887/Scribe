@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\SCRIBE-Server.vbs" 2>nul
echo Removed SCRIBE from Windows startup.
pause

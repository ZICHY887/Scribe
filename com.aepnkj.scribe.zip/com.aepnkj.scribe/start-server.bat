@echo off
title SCRIBE by AEPNKJ — AI Server
cd /d "%~dp0"

if exist "client\index.html" (
  REM Release build, index.html already built
) else if not exist "cep\client\index.html" (
  echo.
  echo Building SCRIBE panel UI ^(first time only^)...
  call npm.cmd run build
  if errorlevel 1 (
    echo.
    echo Build failed. Run from project root: npm.cmd install
    pause
    exit /b 1
  )
  echo.
)

cd server

REM Fix common mistake: .env in server\server\ instead of server\
if not exist ".env" (
  if exist "server\.env" (
    echo Found server\server\.env — copying to server\.env
    copy /Y "server\.env" ".env" >nul
  )
)

if not exist "node_modules\" (
  echo Installing server dependencies...
  call npm.cmd install
  if errorlevel 1 (
    echo.
    echo Failed to install dependencies. Is Node.js installed?
    pause
    exit /b 1
  )
)

if not exist ".env" (
  if exist ".env.example" (
    echo Creating server\.env from .env.example
    copy /Y ".env.example" ".env" >nul
  )
)

echo.
echo ========================================
echo   SCRIBE by AEPNKJ
echo ========================================
echo   Panel UI:  http://127.0.0.1:3742/
echo   Health:    http://127.0.0.1:3742/health
echo.
echo   Keep this window OPEN while using SCRIBE in After Effects.
echo   Press Ctrl+C to stop the server.
echo ========================================
echo.

start "" "http://127.0.0.1:3742/health"

call npm.cmd start

pause
